<template>
  <div
    class="ScaleBox"
    ref="ScaleBox"
    :style="{
      width: width + 'px',
      height: height + 'px',
    }"
  >
    <el-row>
      <el-col :span="24">
        <div class="top">
          <div class="top-title">战略管理域</div>
          <div class="top-title">经营管理域</div>
          <div class="top-title">财务管理域</div>
          <div class="top-title">科研生产域</div>
          <div class="top-text">三江万山智慧大脑</div>
          <div class="top-title left-50 bg-choose">质量管理域</div>
          <div class="top-title top-right">人力资源域</div>
          <div class="top-title top-right">党群建设域</div>
        </div>
      </el-col>
    </el-row>
    <el-row :gutter="8" class="mt-40">
      <el-col :span="7">
        <div class="chart">
          <div class="title">模块一标题</div>
          <div id="oneChart"></div>
          <div id="oneChart2"></div>
        </div>
        <div class="chart">
          <div class="title">模块四标题</div>
          <div id="line"></div>
        </div>
        <div class="chart">
          <div class="title">模块七标题</div>
          <div id="last"></div>
        </div>
      </el-col>
      <el-col :span="10">
        <div class="chart-center">
          <div class="title">模块二标题</div>
          <div class="top-box">
            <div class="top-content">
              <el-col :span="5"
                ><img class="top-img" src="../assets/sanjiang/组 18@2x(6).png"
              /></el-col>
              <el-col :span="12">
                <div>
                  <div class="num">23.13</div>
                  <div class="apply">净利润（亿元）</div>
                </div>
              </el-col>
              <el-col :span="7">
                <div class="content-bottom">
                  环比 <img src="../assets/sanjiang/icon_jt 拷贝@2x.png" /> 10%
                </div>
              </el-col>
            </div>
            <div class="line"></div>
            <div class="top-content">
              <el-col :span="5"
                ><img class="top-img" src="../assets/sanjiang/组 18@2x(7).png"
              /></el-col>
              <el-col :span="12">
                <div>
                  <div class="num">122.13</div>
                  <div class="apply">利润总额（亿元）</div>
                </div>
              </el-col>
              <el-col :span="7">
                <div class="content-bottom">
                  环比 <img src="../assets/sanjiang/icon_jt 拷贝@2x.png" /> 10%
                </div>
              </el-col>
            </div>
            <div class="top-content">
              <el-col :span="5"
                ><img class="top-img" src="../assets/sanjiang/组 18@2x(8).png"
              /></el-col>
              <el-col :span="12">
                <div>
                  <div class="num">23.13</div>
                  <div class="apply">营业收入（亿元）</div>
                </div>
              </el-col>
              <el-col :span="7">
                <div class="content-bottom">
                  环比 <img src="../assets/sanjiang/icon_jt 拷贝@2x.png" /> 10%
                </div>
              </el-col>
            </div>
            <div class="line"></div>
            <div class="top-content">
              <el-col :span="5"
                ><img class="top-img" src="../assets/sanjiang/组 18@2x(11).png"
              /></el-col>
              <el-col :span="12">
                <div>
                  <div class="num">12.32%</div>
                  <div class="apply">资产证券化率</div>
                </div>
              </el-col>
              <el-col :span="7">
                <div class="content-bottom">
                  环比 <img src="../assets/sanjiang/icon_jt 拷贝@2x.png" /> 10%
                </div>
              </el-col>
            </div>
            <div class="top-content">
              <el-col :span="5"
                ><img class="top-img" src="../assets/sanjiang/组 18@2x(9).png"
              /></el-col>
              <el-col :span="12">
                <div>
                  <div class="num">23.13</div>
                  <div class="apply">研发投入强度</div>
                </div>
              </el-col>
              <el-col :span="7">
                <div class="content-bottom" style="color: red">
                  环比
                  <img src="../assets/sanjiang/矩形 622 拷贝 9@2x.png" /> 10%
                </div>
              </el-col>
            </div>
            <div class="line"></div>
            <div class="top-content">
              <el-col :span="5"
                ><img class="top-img" src="../assets/sanjiang/组 18@2x(10).png"
              /></el-col>
              <el-col :span="12">
                <div>
                  <div class="num">23.13</div>
                  <div class="apply">全员劳动生产率</div>
                </div>
              </el-col>
              <el-col :span="7">
                <div class="content-bottom">
                  环比 <img src="../assets/sanjiang/icon_jt 拷贝@2x.png" /> 10%
                </div>
              </el-col>
            </div>
          </div>
        </div>
        <div class="chart-center five">
          <div class="title">模块五标题</div>
          <div id="bar"></div>
        </div>
      </el-col>
      <el-col :span="7">
        <div class="chart">
          <div class="title">模块三标题</div>
          <div class="three-box">
            <img src="../assets/sanjiang/组 24@2x(3).png" alt="" />
            <img src="../assets/sanjiang/组 24@2x(2).png" alt="" />
            <img src="../assets/sanjiang/组 24@2x(4).png" alt="" />
            <div class="content-text">
              <span class="span-box"
                ><span class="five">5</span><span>个</span></span
              >
              <span class="span-box"
                ><span class="five">3</span><span>个</span></span
              >
              <span class="span-box"
                ><span class="five">4</span><span>个</span></span
              >
              <div>
                <span class="span-box2">XX指标</span>
                <span class="span-box2">XX指标</span>
                <span class="span-box2">XX指标</span>
              </div>
            </div>
          </div>
        </div>
        <div class="chart">
          <div class="title">模块六标题</div>
          <div class="content">
            <div class="content-title">147</div>
            <div class="content-content">XX指标</div>
          </div>
          <div class="content ml-10">
            <div class="content-title">27</div>
            <div class="content-content">XX指标</div>
          </div>
          <div class="content bg">
            <div class="content-title" style="color: #c29e6b">234</div>
            <div class="content-content">XX指标</div>
          </div>
          <div class="content ml-10 bg">
            <div class="content-title" style="color: #c29e6b">23</div>
            <div class="content-content">XX指标</div>
          </div>
        </div>
      </el-col>
      <el-col :span="7">
        <div class="chart">
          <div class="title">模块八标题</div>
          <div id="eightChart"></div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import * as echarts from "echarts";
export default {
  name: "ScaleBox",
  data() {
    return {
      scale: "",
      width: 1920,
      height: 1080,
    };
  },
  created() {},
  mounted() {
    this.setScale();
    window.addEventListener("resize", this.debounce(this.setScale, 100));
    this.barChartInit();
    this.lastChartInit();
    this.lineChart();
    this.eightChartInit();
    this.oneChartInit();
  },
  methods: {
    tableRowClassName({ rowIndex }) {
      if (rowIndex % 2 == 0) {
        return "warning-row";
      } else {
        return "";
      }
    },
    oneChartInit() {
      var myChart = echarts.init(document.getElementById("oneChart"));
      var myChart2 = echarts.init(document.getElementById("oneChart2"));
      var value = 64.8;
      var color = new echarts.graphic.LinearGradient(0, 0, 1, 0, [
        {
          offset: 0,
          color: "#D8FD36",
        },
        {
          offset: 1,
          color: "#2AFD85",
        },
      ]);
      const option = {
        series: [
          {
            type: "gauge",
            startAngle: 200,
            endAngle: -20,
            min: 0,
            max: 100,
            radius: "100%",
            axisLine: {
              show: true,
              lineStyle: {
                color: [
                  [
                    100,
                    new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                      {
                        offset: 0,
                        color: "#abea9e",
                      },
                      {
                        offset: 1,
                        color: "#f0ec9b",
                      },
                    ]),
                  ],
                  [1, "rgba(225,225,225,0.4)"],
                ],
                width: 3,
                opacity: 1,
              },
            },
            title: {
              show: false,
            },
            detail: {
              show: true,
              offsetCenter: [0, 0],
              color: "#D6F1FF",
              fontSize: 30,
              formatter: function (value) {
                return (
                  "{value|" + value.toFixed(0) + "}{unit|%}\n{unit2|XX指标}"
                );
              },
              rich: {
                value: {
                  fontSize: 30,
                  color: "#9cf6fb",
                },
                unit: {
                  fontSize:14,
                  color: "#9cf6fb",
                },
                unit2: {
                  fontSize:16,
                  color: "#a8cdee",
                },
              },
            },
            axisTick: {
              length: 0,
              splitNumber: 2,
              lineStyle: {
                color: "#999",
              },
            },
            splitLine: {
              length: 25,
              lineStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                  {
                    offset: 0,
                    color: "#abea9e",
                  },
                  {
                    offset: 1,
                    color: "#f0ec9b",
                  },
                ]),
              },
            },
            axisLabel: {
              show: false
            },
            pointer: {
              show:false,
              width: 12,
              length: 120,
            },
            itemStyle: {
              color: color,
              shadowColor: "rgba(0,138,255,0.45)",
              shadowBlur: 10,
              shadowOffsetX: 2,
              shadowOffsetY: 2,
            },
            data: [
              {
                value: value,
                name: "年售电量情况",
              },
            ],
          },
          {
            type: "gauge",
            radius: "100%",
            startAngle: 200,
            endAngle: -20,
            min: 0,
            max: 100,
            title: {
              show: false,
            },
            detail: {
              show: false,
            },
            axisLine: {
              show: true,
              lineStyle: {
                width: 12,
                color: [
                  [value / 100, color],
                  [1, "#35375C"],
                ],
              },
            },
            axisTick: {
              show: true,
              length: 22,
              splitNumber: 2,
              lineStyle: {
                color: "#192568",
                width: 3,
              },
            },
            splitLine: {
              show: false,
            },
            axisLabel: {
              show: false,
            },
            pointer: {
              show: false,
            },
            itemStyle: {
              normal: {
                color: "#35375C",
              },
            },
          },
        ],
      };
      myChart.setOption(option);
      myChart2.setOption(option);

      window.addEventListener("resize", () => {
        myChart.resize();
        myChart2.resize();
      });
    },
    eightChartInit() {
      var myChart = echarts.init(document.getElementById("eightChart"));

      var category = [
        {
          name: "xx指标",
          value: 3100,
        },
        {
          name: "xx指标",
          value: 2700,
        },
        {
          name: "xx指标",
          value: 1521,
        },
      ]; // 类别
      var total = 3500; // 数据总数
      var datas = [];
      category.forEach((value) => {
        datas.push(value.value);
      });
      const option = {
        xAxis: {
          max: total,
          splitLine: {
            show: false,
          },
          axisLine: {
            show: false,
          },
          axisLabel: {
            show: false,
          },
          axisTick: {
            show: false,
          },
        },
        grid: {
          left: 80,
          top: 20, // 设置条形图的边距
          right: 80,
          bottom: 20,
        },
        yAxis: [
          {
            type: "category",
            inverse: false,
            data: category,
            axisLine: {
              show: false,
            },
            axisTick: {
              show: false,
            },
            axisLabel: {
              show: false,
            },
          },
        ],
        series: [
          {
            // 内
            type: "bar",
            barWidth: 18,
            legendHoverLink: false,
            silent: true,
            itemStyle: {
              normal: {
                color: function (params) {
                  var color;
                  if (params.dataIndex == 0) {
                    color = {
                      type: "linear",
                      x: 0,
                      y: 0,
                      x2: 1,
                      y2: 0,
                      colorStops: [
                        {
                          offset: 0,
                          color: "#655958", // 0% 处的颜色
                        },
                        {
                          offset: 1,
                          color: "#f1d56e", // 100% 处的颜色
                        },
                      ],
                    };
                  } else if (params.dataIndex == 1) {
                    color = {
                      type: "linear",
                      x: 0,
                      y: 0,
                      x2: 1,
                      y2: 0,
                      colorStops: [
                        {
                          offset: 0,
                          color: "#2f5d69", // 0% 处的颜色
                        },
                        {
                          offset: 1,
                          color: "#73dd8d", // 100% 处的颜色
                        },
                      ],
                    };
                  } else {
                    color = {
                      type: "linear",
                      x: 0,
                      y: 0,
                      x2: 1,
                      y2: 0,
                      colorStops: [
                        {
                          offset: 0,
                          color: "#204694", // 0% 处的颜色
                        },
                        {
                          offset: 1,
                          color: "#4fa6f1", // 100% 处的颜色
                        },
                      ],
                    };
                  }
                  return color;
                },
              },
            },
            label: {
              normal: {
                show: true,
                position: "left",
                formatter: "{b}",
                textStyle: {
                  color: "#8baac8",
                  fontSize: 14,
                },
              },
            },
            data: category,
            z: 1,
            animationEasing: "elasticOut",
          },
          {
            // 分隔
            type: "pictorialBar",
            itemStyle: {
              normal: {
                color: "#061348",
              },
            },
            symbolRepeat: "fixed",
            symbolMargin: 6,
            symbol: "rect",
            symbolClip: true,
            symbolSize: [1, 21],
            symbolPosition: "start",
            symbolOffset: [1, -1],
            symbolBoundingData: total,
            data: category,
            z: 2,
            animationEasing: "elasticOut",
          },
          {
            // 外边框
            type: "pictorialBar",
            symbol: "rect",
            symbolBoundingData: total,
            itemStyle: {
              normal: {
                color: "none",
              },
            },
            label: {
              normal: {
                formatter: (params) => {
                  var text;
                  if (params.dataIndex == 1) {
                    text = "{f|  " + params.data + "}";
                  } else if (params.dataIndex == 2) {
                    text = "{f|  " + params.data + "}";
                  } else if (params.dataIndex == 3) {
                    text = "{f|  " + params.data + "}";
                  } else {
                    text = "{f|  " + params.data + "}";
                  }
                  return text;
                },
                rich: {
                  a: {
                    color: "red",
                  },
                  b: {
                    color: "blue",
                  },
                  c: {
                    color: "yellow",
                  },
                  d: {
                    color: "green",
                  },
                  f: {
                    color: "#ffffff",
                    fontSize: 16,
                  },
                },
                position: "right",
                distance: 0, // 向右偏移位置
                show: true,
              },
            },
            data: datas,
            z: 0,
            animationEasing: "elasticOut",
          },
          {
            name: "外框",
            type: "bar",
            barGap: "-120%", // 设置外框粗细
            data: [total, total, total],
            barWidth: 25,
            itemStyle: {
              normal: {
                color: "transparent", // 填充色
                barBorderColor: "#1C4B8E", // 边框色
                barBorderWidth: 1, // 边框宽度
                // barBorderRadius: 0, //圆角半径
                label: {
                  // 标签显示位置
                  show: false,
                  position: "top", // insideTop 或者横向的 insideLeft
                },
              },
            },
            z: 0,
          },
        ],
      };
      myChart.setOption(option);

      window.addEventListener("resize", () => {
        myChart.resize();
      });
    },
    barChartInit() {
      var myChart = echarts.init(document.getElementById("bar"));
      const option = {
        grid: {
          top: "20%",
          left: "13%",
          right: "13%",
          bottom: "10%",
        },

        label: {
          show: true,
          position: "top",
          color: "#fff",
        },
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "shadow",
          },
        },
        legend: {
          left: "center",
          textStyle: {
            color: "#fff", //legend字体颜色
          },
        },
        xAxis: {
          type: "category",
          axisTick: { show: false },
          data: [
            "指标1",
            "指标2",
            "指标3",
            "指标4",
            "指标5",
            "指标6",
            "指标7",
            "指标8",
            "指标9",
            "指标10",
          ],
          axisLabel: {
            show: true,
            textStyle: {
              color: "#fff",
            },
          },
        },

        yAxis: [
          {
            name: "单位:万元",
            nameTextStyle: {
              color: "#fff",
              padding: 20,
            },
            type: "value",
            splitLine: {
              show: false,
            },
            axisLabel: {
              show: true,
              textStyle: {
                color: "#fff",
              },
            },
          },
        ],
        series: [
          {
            type: "bar",
            barGap: "30%",
            barWidth: "40%",
            borderColor: "red",
            borderWidth: 1,

            tooltip: {
              valueFormatter: function (value) {
                return value + "%";
              },
            },
            emphasis: {
              focus: "series",
            },
            itemStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                {
                  offset: 0,
                  color: "rgba(57, 119, 223, .8)",
                },
                {
                  offset: 1,
                  color: "rgba(22,75,247,0.1)",
                },
              ]),
            },
            data: [80, 98, 62, 80, 62, 100, 80, 98, 62, 88],
          },
        ],
      };

      myChart.setOption(option);

      window.addEventListener("resize", () => {
        myChart.resize();
      });
    },
    lastChartInit() {
      var myChart = echarts.init(document.getElementById("last"));
      const option = {
        legend: {
          top: "25%",
          left: "80%",
          orient: "vertical",
          textStyle: {
            color: "#536796", //legend字体颜色
          },
        },
        label: {
          show: true,
          position: "top",
          color: "#fff",
          formatter: "{name|{d}%}\n{value|{b}}",
          rich: {
            name: {
              fontSize: 12,
              color: "#fff",
            },
            value: {
              fontSize: 16,
              color: "#5c8ef3",
            },
          },
        },
        series: [
          {
            type: "pie",
            radius: ["50%", "80%"],
            data: [
              { value: 1048, name: "XX指标" },
              { value: 735, name: "XX指标2" },
              { value: 580, name: "XX指标3" },
            ],
          },
        ],
      };
      myChart.setOption(option);

      window.addEventListener("resize", () => {
        myChart.resize();
      });
    },
    lineChart() {
      var myChart = echarts.init(document.getElementById("line"));
      const option = {
        grid: {
          top: "20%",
          left: "17%",
          right: "13%",
          bottom: "10%",
        },

        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "shadow",
          },
        },
        xAxis: {
          type: "category",
          axisTick: { show: false },
          data: [
            "02-15",
            "02-16",
            "02-17",
            "02-18",
            "02-19",
            "02-20",
            "02-21",
            "02-22",
          ],
          axisLabel: {
            show: true,
            textStyle: {
              color: "#fff",
            },
          },
        },

        yAxis: {
          nameTextStyle: {
            color: "#fff",
            padding: 20,
          },
          splitLine: {
            show: false,
          },
          axisLabel: {
            show: true,
            textStyle: {
              color: "#fff",
            },
          },
        },

        series: [
          {
            type: "line",
            smooth: true,
            symbol: "none",
            itemStyle: {
              normal: {
                color: "#4b94cb",
                lineStyle: {
                  color: "#4b94cb",
                },
              },
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                {
                  offset: 0,
                  color: "rgba(99, 195, 237,0.8)", //靠上方的透明颜色
                },
                {
                  offset: 1,
                  color: "rgba(0, 0, 84,0.3)", //靠下方的透明颜色
                },
              ]),
            },
            data: [120, 97, 38, 110, 62, 100, 65, 95],
          },
          {
            type: "line",
            smooth: true,
            symbol: "none",
            itemStyle: {
              normal: {
                color: "#4b94cb",
                lineStyle: {
                  color: "#5abf9d",
                },
              },
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                {
                  offset: 0,
                  color: "rgba(91, 191, 158,0.8)", //靠上方的透明颜色
                },
                {
                  offset: 1,
                  color: "rgba(0, 0, 84,0.3)", //靠下方的透明颜色
                },
              ]),
            },
            data: [120, 57, 68, 120, 70, 100, 95, 95],
          },
        ],
      };

      myChart.setOption(option);

      window.addEventListener("resize", () => {
        myChart.resize();
      });
    },
    getScale() {
      let { width, height } = this;
      let wh = window.innerHeight / height;
      let ww = window.innerWidth / width;
      return ww < wh ? ww : wh;
    },
    setScale() {
      this.scale = this.getScale();
      if (this.$refs.ScaleBox) {
        this.$refs.ScaleBox.style.setProperty("--scale", this.scale);
      }
    },
    debounce(fn, delay) {
      let delays = delay || 500;
      let timer;
      return function () {
        let th = this;
        let args = arguments;
        if (timer) {
          clearTimeout(timer);
        }
        timer = setTimeout(function () {
          timer = null;
          fn.apply(th, args);
        }, delays);
      };
    },
  },
};
</script>

<style scoped lang="scss">
/deep/.el-input__inner {
  background-color: rgba(0, 222, 255, 0.24);
  color: #fff;
  width: 144px;
  height: 38px;
  box-shadow: 0px 0px 16px 0px rgba(131, 219, 255, 0.2) inset;
  border-radius: 4px;
  border: none;
}
/deep/.el-form-item__label {
  color: #fff;
}
/deep/.el-input {
  width: 180px;
}

/deep/.el-button--primary {
  background: linear-gradient(0deg, #17e0fe, #0783cf);
}
/deep/.el-button {
  color: #fff;
  background-color: rgba(0, 222, 255, 0.24);
  box-shadow: 0px 0px 16px 0px rgba(131, 219, 255, 0.2) inset;
  border-radius: 4px;
  border: none;
}
/deep/.el-table tbody tr:hover > td {
  background: #0e183e !important;
}
/deep/.el-table {
  color: #00ffff;
  border: none;
  margin: 0;
}
/deep/table {
  width: 1232px !important;
}
/deep/.el-table tr {
  background-color: #071844;
}
/deep/.el-table td.el-table__cell {
  border: none;
}
/deep/.el-table__header {
  width: 1232px;
}
// 去掉表格单元格边框
/deep/.customer-table th {
  border: none;
}
/deep/.customer-table td,
.customer-table th.is-leaf {
  border: none;
}

// 头部边框
/deep/.customer-table thead tr th.is-leaf {
  border: none;
}
/deep/.customer-table thead tr th:nth-last-of-type(2) {
  border: none;
}
// 表格最外层边框-底部边框
/deep/.el-table--border::after,
.el-table--group::after {
  width: 0;
}
/deep/.customer-table::before {
  width: 0;
}
/deep/.customer-table .el-table__fixed-right::before,
.el-table__fixed::before {
  width: 0;
}

::v-deep .el-table__row.warning-row {
  background-color: #0e2550;
}
.form-search {
  margin: 20px 0 30px;
}
#ScaleBox {
  --scale: 1;
}
.ScaleBox {
  padding: 15px;
  position: absolute;
  transform: scale(var(--scale)) translate(-50%, -50%);
  display: flex;
  flex-direction: column;
  transform-origin: 0 0;
  left: 50%;
  top: 50%;
  transition: 0.3s;
  z-index: 999;
  background-color: #000337;
}
.page-content {
  padding: 20px 0;
}
.top {
  height: 80px;
  background: #000337;
  background: url("../assets/sanjiang/形状\ 14@2x.png") 62% 100% no-repeat;
  font-family: Source Han Sans CN;
  position: relative;
  .top-title {
    display: inline-block;
    width: 188px;
    height: 70px;
    margin-top: 25px;
    line-height: 100px;
    text-align: center;
    color: #2e9eff;
    background: url("../assets/sanjiang/1@2x.png") 50% 100% no-repeat;
  }
  .bg-choose{
    background: url("../assets/sanjiang/1@2x(1).png") 50% 100% no-repeat;
    color: #fff;
  }
  .top-text {
    position: absolute;
    top: -15px;
    left: 750px;
    background-image: -webkit-linear-gradient(bottom, #fff, #61f4f9);
    margin-left: 80px;
    width: 300px;
    height: 40px;
    margin-top: 40px;
    font-size: 32px;
    display: inline-block;
    font-weight: bold;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    overflow: hidden;
  }
  .left-50 {
    margin-left: 450px;
  }
  .top-right {
    margin-left: 20px;
  }
}
.chart {
  background: url("../assets/sanjiang/组\ 24@2x\(6\).png") no-repeat;
  background-size: cover;
  background-size: 100% 98%;
  width: 100%;
  height: 317px;
  .title {
    font-weight: 600;
    text-align: center;
    font-size: 20px;
    line-height: 70px;
    background-image: linear-gradient(
      92deg,
      #000054 35%,
      #b1f5fa 48.8525390625%,
      #75c8fa 100%
    );
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }
}
.mt-40 {
  margin-top: 35px;
}
.ml-10 {
  margin-left: 10px !important;
}
.chart-center {
  background: url("../assets/sanjiang/组\ 24@2x\(5\).png") no-repeat;
  background-size: 100% 97%;
  width: 100%;
  height: 480px;
  .title {
    font-weight: 600;
    text-align: center;
    font-size: 20px;
    line-height: 70px;
    background-image: linear-gradient(
      92deg,
      #000054 35%,
      #b1f5fa 48.8525390625%,
      #75c8fa 100%
    );
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }
}
#bar {
  height: 350px;
}
#line {
  height: 200px;
}

#last {
  height: 200px;
}
#eightChart {
  height: 200px;
}
#oneChart {
  height: 200px;
  display: inline-block;
  margin-top: 40px;
  width: 275px;
}
#oneChart2 {
  display: inline-block;
  height: 200px;
  margin-top: 40px;
  width: 275px;
}
.five {
  position: relative;
  img {
    position: absolute;
    top: 250px;
    left: 40px;
    width: 400px;
  }
}
.bottom-title {
  color: #fff;
  text-align: center;
  margin-top: 15px;
  span {
    margin-right: 15px;
    background: linear-gradient(
      0deg,
      rgba(51, 214, 255, 0.3),
      rgba(51, 229, 255, 0.8)
    );
    border-radius: 10px;
    padding: 5px 10px;
    font-size: 14px;
    cursor: pointer;
  }
  span:last-child {
    background: linear-gradient(
      0deg,
      rgba(255, 226, 101, 0.6),
      rgba(255, 156, 0, 0.6)
    );
  }
}
.three-box {
  text-align: center;
  img {
    margin-top: -15px;
  }
}
.bg {
  background: url("../assets/sanjiang/组\ 24@2x\(1\).png") no-repeat !important;
  background-size: 100% 100% !important;
}
.content-text {
  color: #9cf5fb;
  .five {
    font-weight: 600;
    font-size: 30px;
    margin-right: 5px;
  }
  .span-box {
    margin: 0 50px;
  }
  .span-box2 {
    margin: 0 44px;
    color: #92a9c5;
  }
}
.content {
  padding: 10px;
  background: url("../assets/sanjiang/组\ 18@2x\(3\).png") no-repeat;
  background-size: 100% 100%;
  box-sizing: border-box;
  width: 250px;
  height: 100px;
  display: inline-block;
  margin: 10px 0 0 20px;
  text-align: center;
  .content-title {
    font-size: 38px;
    color: #9cf6fb;
    font-weight: 500;
  }
  .content-content {
    font-size: 16px;
    color: #fff;
    span {
      font-size: 14px;
    }
  }
  .content-bottom {
    width: 100px;
    height: 20px;
    line-height: 20px;
    margin-top: 15px;
    text-align: center;
    font-size: 12px;
    color: #3dff00;
    box-shadow: 0px 12px 7px 0px rgba(16, 85, 216, 0.35) inset;
    border: 1px solid #209bd3;
    border-radius: 100px;
    img {
      width: 18px;
    }
  }
}
.top-box {
  padding: 30px 50px;
  .line {
    display: inline-block;
    width: 1px;
    height: 100px;
    margin: 0 45px;
    background: linear-gradient(
      0deg,
      rgba(255, 255, 255, 0) 0%,
      rgba(70, 226, 255, 0.97) 50%,
      rgba(255, 255, 255, 0) 100%
    );
  }
  .top-content {
    width: 300px;
    font-size: 16px;
    margin-bottom: 20px;
    display: inline-block;
    line-height: 32px;
    color: #fff;
    height: 70px;

    .top-img {
      display: block;
      width: 60px;
    }
    .apply {
      font-size: 13px !important;
    }
    .num {
      font-size: 30px;
      font-weight: 600;
      background: linear-gradient(0deg, #2bb3ff 0%, #38e7ee 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    .content-bottom {
      width: 100px;
      height: 20px;
      line-height: 20px;
      margin-top: 15px;
      text-align: center;
      font-size: 12px;
      color: #3dff00;
      border: 1px solid #209bd3;
      border-radius: 100px;
      box-shadow: 0px 12px 7px 0px rgba(16, 85, 216, 0.35) inset;
      img {
        width: 18px;
      }
    }
  }
}

.right-box {
  width: 150px;
  font-size: 14px;
  color: #fff;
  float: right;
  margin-top: 25px;
  line-height: 18px;
  cursor: pointer;
  .right-content {
    // padding: 35px 20px;
    img {
      display: block;
      width: 20px;
      margin-top: 7px;
    }
    .num {
      text-align: left;
    }
    .apply {
      text-align: left;
    }
  }
}
</style>
