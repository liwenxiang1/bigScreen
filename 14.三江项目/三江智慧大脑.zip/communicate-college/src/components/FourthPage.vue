<template>
  <div
    class="ScaleBox"
    ref="ScaleBox"
    :style="{
      width: width + 'px',
      height: height + 'px',
    }"
  >
    <el-row>
      <el-col :span="24">
        <div class="top">
          <div class="top-title">战略管理域</div>
          <div class="top-title">经营管理域</div>
          <div class="top-title">财务管理域</div>
          <div class="top-title bg-choose">科研生产域</div>
          <div class="top-text">三江万山智慧大脑</div>
          <div class="top-title left-50">质量管理域</div>
          <div class="top-title top-right">人力资源域</div>
          <div class="top-title top-right">党群建设域</div>
        </div>
      </el-col>
    </el-row>
    <el-row :gutter="8" class="mt-40">
      <el-col :span="8">
        <div class="chart">
          <div class="title">模块一标题</div>
          <div class="content">
            <div class="content-title">XX.XX</div>
            <div class="content-content">XX指标</div>
          </div>
          <div class="content ml-10">
            <div class="content-title">XX.XX</div>
            <div class="content-content">XX指标</div>
          </div>
          <div class="content bg">
            <div class="content-title" style="color: #f5be4c">XX.XX</div>
            <div class="content-content">XX指标</div>
          </div>
          <div class="content ml-10 bg">
            <div class="content-title" style="color: #f5be4c">XX.XX</div>
            <div class="content-content">XX指标</div>
          </div>
        </div>
      </el-col>
      <el-col :span="8">
        <div class="chart">
          <div class="title">模块二标题</div>
          <div id="rate"></div>
          <div class="right-two-box">
            <div class="two-title">
              <div class="titles"></div>
              <span>XX指标</span>
              <div class="nums">
                <span class="num color1">1,234</span> <span>万亿</span>
              </div>
            </div>
            <div class="two-title">
              <div class="titles" style="background-color: #65b24e"></div>
              <span>XX指标</span>
              <div class="nums">
                <span class="num color2">1,234</span> <span>万亿</span>
              </div>
            </div>
            <div class="two-title">
              <div class="titles" style="background-color: #e4893d"></div>
              <span>XX指标</span>
              <div class="nums">
                <span class="num color3">1,234</span> <span>万亿</span>
              </div>
            </div>
            <div class="two-title">
              <div class="titles" style="background-color: #62cbec"></div>
              <span>XX指标</span>
              <div class="nums">
                <span class="num color4">1,234</span> <span>万亿</span>
              </div>
            </div>
          </div>
        </div>
      </el-col>
      <el-col :span="8">
        <div class="chart">
          <div class="title">模块三标题</div>
          <div id="line"></div>
        </div>
      </el-col>

      <el-col :span="6">
        <div class="chart five">
          <div class="title">模块四标题</div>
          <img class="dizuo" src="../assets/sanjiang/dizuo.png" />
          <div id="categoryDiv" style="height: 300px"></div>
        </div>
      </el-col>
      <el-col :span="6">
        <div class="chart">
          <div class="title">模块五标题</div>
          <div id="oneChart"></div>
          <div id="oneChart2"></div>
        </div>
      </el-col>
      <el-col :span="6">
        <div class="chart">
          <div class="title">模块六标题</div>
          <div id="eightChart"></div>
        </div>
      </el-col>
      <el-col :span="6">
        <div class="chart">
          <div class="title">模块七标题</div>
          <div id="bar"></div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import * as echarts from "echarts";
import "echarts-gl";
// 生成扇形的曲面参数方程，用于 series-surface.parametricEquation
function getParametricEquation(startRatio, endRatio, isSelected, isHovered, k) {
  // 计算
  let midRatio = (startRatio + endRatio) / 2;

  let startRadian = startRatio * Math.PI * 2;
  let endRadian = endRatio * Math.PI * 2;
  let midRadian = midRatio * Math.PI * 2;

  // 如果只有一个扇形，则不实现选中效果。
  if (startRatio === 0 && endRatio === 1) {
    isSelected = false;
  }

  // 通过扇形内径/外径的值，换算出辅助参数 k（默认值 1/3）
  k = typeof k !== "undefined" ? k : 1 / 3;

  // 计算选中效果分别在 x 轴、y 轴方向上的位移（未选中，则位移均为 0）
  let offsetX = isSelected ? Math.cos(midRadian) * 0.1 : 0;
  let offsetY = isSelected ? Math.sin(midRadian) * 0.1 : 0;

  // 计算高亮效果的放大比例（未高亮，则比例为 1）
  let hoverRate = isHovered ? 1.05 : 1;

  // 返回曲面参数方程
  return {
    u: {
      min: -Math.PI,
      max: Math.PI * 3,
      step: Math.PI / 32,
    },

    v: {
      min: 0,
      max: Math.PI * 2,
      step: Math.PI / 20,
    },

    x: function (u, v) {
      if (u < startRadian) {
        return (
          offsetX + Math.cos(startRadian) * (1 + Math.cos(v) * k) * hoverRate
        );
      }
      if (u > endRadian) {
        return (
          offsetX + Math.cos(endRadian) * (1 + Math.cos(v) * k) * hoverRate
        );
      }
      return offsetX + Math.cos(u) * (1 + Math.cos(v) * k) * hoverRate;
    },

    y: function (u, v) {
      if (u < startRadian) {
        return (
          offsetY + Math.sin(startRadian) * (1 + Math.cos(v) * k) * hoverRate
        );
      }
      if (u > endRadian) {
        return (
          offsetY + Math.sin(endRadian) * (1 + Math.cos(v) * k) * hoverRate
        );
      }
      return offsetY + Math.sin(u) * (1 + Math.cos(v) * k) * hoverRate;
    },

    z: function (u, v) {
      if (u < -Math.PI * 0.5) {
        return Math.sin(u);
      }
      if (u > Math.PI * 2.5) {
        return Math.sin(u);
      }
      return Math.sin(v) > 0 ? 1 : -1;
    },
  };
}
const optionData = [
  {
    name: "xx指标1",
    value: 25,
    itemStyle:{
      color: '#50abf7'
    }
  },
  {
    name: "xx指标2",
    value: 3,
    itemStyle: {
      color: "#61d4e6",
    },
  },
];
// 生成模拟 3D 饼图的配置项
function getPie3D(pieData, internalDiameterRatio) {
  let series = [];
  let sumValue = 0;
  let startValue = 0;
  let endValue = 0;
  let legendData = [];
  let k =
    typeof internalDiameterRatio !== "undefined"
      ? (1 - internalDiameterRatio) / (1 + internalDiameterRatio)
      : 1 / 3;

  // 为每一个饼图数据，生成一个 series-surface 配置
  for (let i = 0; i < pieData.length; i++) {
    sumValue += pieData[i].value;
    let seriesItem = {
      name:
        typeof pieData[i].name === "undefined" ? `series${i}` : pieData[i].name,
      type: "surface",
      parametric: true,
      wireframe: {
        show: false,
      },
      pieData: pieData[i],
      pieStatus: {
        selected: false,
        hovered: false,
        k: k,
      },
    };

    if (typeof pieData[i].itemStyle != "undefined") {
      let itemStyle = {};

      typeof pieData[i].itemStyle.color != "undefined"
        ? (itemStyle.color = pieData[i].itemStyle.color)
        : null;
      typeof pieData[i].itemStyle.opacity != "undefined"
        ? (itemStyle.opacity = pieData[i].itemStyle.opacity)
        : null;

      seriesItem.itemStyle = itemStyle;
    }
    series.push(seriesItem);
  }

  // 使用上一次遍历时，计算出的数据和 sumValue，调用 getParametricEquation 函数，
  // 向每个 series-surface 传入不同的参数方程 series-surface.parametricEquation，也就是实现每一个扇形。
  for (let i = 0; i < series.length; i++) {
    endValue = startValue + series[i].pieData.value;

    series[i].pieData.startRatio = startValue / sumValue;
    series[i].pieData.endRatio = endValue / sumValue;
    series[i].parametricEquation = getParametricEquation(
      series[i].pieData.startRatio,
      series[i].pieData.endRatio,
      true,
      false,
      1
    );

    startValue = endValue;

    legendData.push(series[i].name);
  }

  series.push({
    backgroundColor: "transparent",
    type: "pie",
    label: {
      opacity: 1,
      fontSize: 30,
      lineHeight: 100,
      formatter: "{d|{d}%}",
      padding:[0,-80,30,-70],
      rich: {
        d: {
          color: "#6cddde",
          fontSize: 20,
          lineHeight: 24,
          height: 24,
          fontWeight:600
        },
      },
      textStyle: {
        color: "#fff",
        align: "right",
        fontSize: 14,
      },
    },
    labelLine:{
      length: 60,
      length2: 70,
    },
    startAngle: -20, // 起始角度，支持范围[0, 360]。
    clockwise: false, // 饼图的扇区是否是顺时针排布。上述这两项配置主要是为了对齐3d的样式
    radius: ["50%", "50%"],
    center: ["55%", "55%"],
    data: optionData,
    itemStyle: {
      opacity: 0, //这里必须是0，不然2d的图会覆盖在表面
    },
  });
  // 准备待返回的配置项，把准备好的 legendData、series 传入。
  let option = {
    legend: {
      show: false,
      data: legendData,
    },
    xAxis3D: {
      min: -1.3,
      max: 1.3,
    },
    yAxis3D: {
      min: -1.3,
      max: 1.3,
    },
    zAxis3D: {
      min: -1.3,
      max: 1.3,
    },
    grid3D: {
      show: false,
      boxHeight: 14,
      // top: '30%',
      left: "0",
      bottom: "50%",
      viewControl: {
        //3d效果可以放大、旋转等，请自己去查看官方配置
        alpha: 20,
        // beta: 40,
        rotateSensitivity: 12,
        zoomSensitivity: 0,
        panSensitivity: 0,
        autoRotate: false,
        autoRotateSpeed: 3,
        //   autoRotateAfterStill: 10
      },
    },
    series: series,
  };
  return option;
}

// 传入数据生成 option
const option = getPie3D(optionData, 0.59);
const categoryInit = () => {
  let pie3D = echarts.init(document.getElementById("categoryDiv"));
  pie3D.setOption(option);
};
export default {
  name: "ScaleBox",
  data() {
    return {
      scale: "",
      width: 1920,
      height: 1080,
    };
  },
  created() {},
  mounted() {
    this.setScale();
    window.addEventListener("resize", this.debounce(this.setScale, 100));
    this.barChartInit();
    this.lastChartInit();
    this.lineChart();
    this.eightChartInit();
    this.oneChartInit();
    this.oneChartInit2();
    this.rateChartInit();
    categoryInit();
  },
  methods: {
    tableRowClassName({ rowIndex }) {
      if (rowIndex % 2 == 0) {
        return "warning-row";
      } else {
        return "";
      }
    },
    rateChartInit() {
      var myChart = echarts.init(document.getElementById("rate"));
      let value = "4432";
      let title = "总计万亿";
      let text = value.replace(/\d{1,3}(?=(\d{3})+$)/g, function (s) {
        return s + ",";
      });

      const option = {
        title: {
          text: "{a|" + text + "}\n{c|" + title + "}",
          x: "center",
          y: "center",
          textStyle: {
            rich: {
              a: {
                fontSize: 38,
                color: "#72dafb",
                fontWeight: 600,
                lineHeight: 50,
              },
              b: {
                fontSize: 38,
                color: "#29EEF3",
              },
              c: {
                fontSize: 18,
                color: "#ffffff",
                padding: [5, 0],
              },
            },
          },
        },
        series: [
          {
            type: "gauge",
            radius: "65%",
            clockwise: true,
            startAngle: "90",
            endAngle: "-269.9999",
            splitNumber: 30,
            detail: {
              offsetCenter: [0, -20],
              formatter: " ",
            },
            pointer: {
              show: false,
            },
            axisLine: {
              show: true,
              lineStyle: {
                color: [
                  [
                    0.25,
                    new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                      {
                        offset: 0.1,
                        color: "#65b24f",
                      },
                      {
                        offset: 1,
                        color: "#15264c",
                      },
                    ]),
                  ],
                  [
                    0.5,
                    new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                      {
                        offset: 0.1,
                        color: "#372049",
                      },
                      {
                        offset: 1,
                        color: "#e3883d",
                      },
                    ]),
                  ],
                  [
                    0.75,
                    new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                      {
                        offset: 0.1,
                        color: "#0d226d",
                      },
                      {
                        offset: 1,
                        color: "#5fc7ed",
                      },
                    ]),
                  ],
                  [
                    1,
                    new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                      {
                        offset: 0.1,
                        color: "#428bd2",
                      },
                      {
                        offset: 1,
                        color: "#0f2374",
                      },
                    ]),
                  ],
                ],
                width: 20,
              },
            },
            axisTick: {
              show: false,
            },
            splitLine: {
              show: true,
              length: 20,
              distance: -20,
              lineStyle: {
                color: "#000054",
                width: 6,
              },
            },
            axisLabel: {
              show: false,
            },
          },
          {
            type: "pie",
            name: "内层细圆环",
            radius: ["43%", "45%"],
            hoverAnimation: false,
            startAngle: 200,
            itemStyle: {
              normal: {
                color: {
                  type: "linear",
                  x: 0,
                  y: 0,
                  x2: 0,
                  y2: 1,
                  colorStops: [
                    {
                      offset: 0,
                      color: "#00a7fb", // 0% 处的颜色
                    },
                    {
                      offset: 0.3,
                      color: "#00a7fb80", // 100% 处的颜色
                    },
                    {
                      offset: 0.4,
                      color: "#00a7fb50", // 100% 处的颜色
                    },
                    {
                      offset: 1,
                      color: "#00a7fb10", // 100% 处的颜色
                    },
                  ],
                },
              },
            },
            label: {
              show: false,
            },
            data: [100],
          },
        ],
      };
      myChart.setOption(option);
      window.addEventListener("resize", () => {
        myChart.resize();
      });
    },
    oneChartInit() {
      var myChart = echarts.init(document.getElementById("oneChart"));
      var data = {
        name: "XX指标",
        value: [35],
        nAmount: 1566557.14,
      };

      var color = ["#00FDFA", "#00B1BF", "#00F7F8"];

      const option = {
        title: [
          {
            text: 234,
            textStyle: {
              color: color[2],
              fontSize: 30,
            },
            itemGap: 20,
            left: "40%",
            top: "22%",
          },
          {
            text: "单位",
            textStyle: {
              color: "#b0b5c4",
              fontSize: 16,
            },
            itemGap: 20,
            left: "46%",
            top: "32%",
          },
        ],
        graphic: [
          {
            type: "text",
            z: 100,
            left: "42%",
            top: "60%",
            style: {
              fill: "#68e0e4",
              text: data.name,
              font: "20px Microsoft YaHei",
            },
          },
        ],
        angleAxis: {
          max: 100,
          clockwise: false, // 逆时针
          // 隐藏刻度线
          show: false,
          startAngle: 110,
        },
        radiusAxis: {
          type: "category",
          show: true,
          axisLabel: {
            show: false,
          },
          axisLine: {
            show: false,
          },
          axisTick: {
            show: false,
          },
        },
        polar: [
          {
            center: ["55%", "30%"], //中心点位置
            radius: "85%", //图形大小
          },
        ],
        series: [
          {
            name: "小环",
            type: "gauge",
            splitNumber: 12,
            radius: "85%",
            center: ["55%", "30%"],
            startAngle: 0,
            endAngle: 720,
            axisLine: {
              show: false,
            },
            axisTick: {
              show: true,
              lineStyle: {
                color: color[1],
                width: 1,
                shadowBlur: 1,
                shadowColor: color[1],
              },
              length: 8,
              splitNumber: 6,
            },
            splitLine: {
              show: false,
            },
            axisLabel: {
              show: false,
            },
            detail: {
              show: false,
            },
          },
          {
            type: "bar",
            z: 10,
            data: data.value,
            showBackground: false,
            backgroundStyle: {
              color: color[1],
              borderWidth: 10,
              width: 10,
            },
            coordinateSystem: "polar",
            roundCap: true,
            barWidth: 8,
            itemStyle: {
              normal: {
                opacity: 1,
                color: new echarts.graphic.LinearGradient(0, 0, 1, 1, [
                  {
                    offset: 0,
                    color: color[0],
                  },
                  {
                    offset: 1,
                    color: "#b5f6fd",
                  },
                ]),
                shadowBlur: 5,
                shadowColor: "#2A95F9",
              },
            },
          },
          {
            type: "pie",
            name: "内层细圆环",
            radius: ["45%", "43%"],
            startAngle: 110,
            center: ["55%", "30%"],
            hoverAnimation: false,
            clockWise: true,
            itemStyle: {
              normal: {
                color: new echarts.graphic.LinearGradient(0, 0, 1, 1, [
                  {
                    offset: 0,
                    color: color[0],
                  },
                  {
                    offset: 1,
                    color: color[1],
                  },
                ]),
              },
            },
            tooltip: {
              show: false,
            },
            label: {
              show: false,
            },
            data: [100],
          },
        ],
      };

      myChart.setOption(option);

      window.addEventListener("resize", () => {
        myChart.resize();
      });
    },
    oneChartInit2() {
      var myChart2 = echarts.init(document.getElementById("oneChart2"));
      var data = {
        name: "XX指标",
        value: [50],
        nAmount: 1566557.14,
      };

      var color = ["#72f3b2", "#72f3b2", "#72f3b2"];

      const option = {
        title: [
          {
            text: data.value[0] + "% ",
            textStyle: {
              color: color[0],
              fontSize: 28,
            },
            itemGap: 20,
            left: "40%",
            top: "22%",
          },
          {
            text: "单位",
            textStyle: {
              color: "#b0b5c4",
              fontSize: 16,
            },
            itemGap: 20,
            left: "46%",
            top: "32%",
          },
        ],
        graphic: [
          {
            type: "text",
            z: 100,
            left: "42%",
            top: "60%",
            style: {
              fill: "#68e0e4",
              text: data.name,
              font: "20px Microsoft YaHei",
            },
          },
        ],
        angleAxis: {
          max: 100,
          clockwise: false, // 逆时针
          // 隐藏刻度线
          show: false,
          startAngle: 110,
        },
        radiusAxis: {
          type: "category",
          show: true,
          axisLabel: {
            show: false,
          },
          axisLine: {
            show: false,
          },
          axisTick: {
            show: false,
          },
        },
        polar: [
          {
            center: ["55%", "30%"], //中心点位置
            radius: "85%", //图形大小
          },
        ],
        series: [
          {
            name: "小环",
            type: "gauge",
            splitNumber: 12,
            radius: "85%",
            center: ["55%", "30%"],
            startAngle: 0,
            endAngle: 720,
            axisLine: {
              show: false,
            },
            axisTick: {
              show: true,
              lineStyle: {
                color: color[1],
                width: 1,
                shadowBlur: 1,
                shadowColor: color[1],
              },
              length: 8,
              splitNumber: 6,
            },
            splitLine: {
              show: false,
            },
            axisLabel: {
              show: false,
            },
            detail: {
              show: false,
            },
          },
          {
            type: "bar",
            z: 10,
            data: data.value,
            coordinateSystem: "polar",
            roundCap: true,
            barWidth: 8,
            itemStyle: {
              normal: {
                opacity: 1,
                color: new echarts.graphic.LinearGradient(0, 0, 1, 1, [
                  {
                    offset: 0,
                    color: "#aefbde",
                  },
                  {
                    offset: 1,
                    color: color[0],
                  },
                ]),
                shadowBlur: 5,
                shadowColor: "#2A95F9",
              },
            },
          },
          {
            type: "pie",
            name: "内层细圆环",
            radius: ["45%", "43%"],
            startAngle: 110,
            center: ["55%", "30%"],
            hoverAnimation: false,
            clockWise: true,
            itemStyle: {
              normal: {
                color: new echarts.graphic.LinearGradient(0, 0, 1, 1, [
                  {
                    offset: 0,
                    color: color[0],
                  },
                  {
                    offset: 1,
                    color: color[1],
                  },
                ]),
              },
            },
            tooltip: {
              show: false,
            },
            label: {
              show: false,
            },
            data: [100],
          },
        ],
      };
      myChart2.setOption(option);

      window.addEventListener("resize", () => {
        myChart2.resize();
      });
    },
    eightChartInit() {
      var myChart = echarts.init(document.getElementById("eightChart"));

      var category = [
        {
          name: "xx指标",
          value: 3100,
        },
        {
          name: "xx指标",
          value: 2700,
        },
        {
          name: "xx指标",
          value: 1521,
        },
        {
          name: "xx指标",
          value: 1421,
        },
        {
          name: "xx指标",
          value: 1621,
        },
        {
          name: "xx指标",
          value: 1721,
        },
      ]; // 类别
      var total = 3500; // 数据总数
      var datas = [];
      category.forEach((value) => {
        datas.push(value.value);
      });
      const option = {
        xAxis: {
          max: total,
          splitLine: {
            show: false,
          },
          axisLine: {
            show: false,
          },
          axisLabel: {
            show: false,
          },
          axisTick: {
            show: false,
          },
        },
        grid: {
          left: 80,
          top: 20, // 设置条形图的边距
          right: 80,
          bottom: 20,
        },
        yAxis: [
          {
            type: "category",
            inverse: false,
            data: category,
            axisLine: {
              show: false,
            },
            axisTick: {
              show: false,
            },
            axisLabel: {
              show: false,
            },
          },
        ],
        series: [
          {
            // 内
            type: "bar",
            barWidth: 18,
            legendHoverLink: false,
            silent: true,
            itemStyle: {
              normal: {
                color: function (params) {
                  var color;
                  if (params.dataIndex == 100) {
                    color = {
                      type: "linear",
                      x: 0,
                      y: 0,
                      x2: 1,
                      y2: 0,
                      colorStops: [
                        {
                          offset: 0,
                          color: "#655958", // 0% 处的颜色
                        },
                        {
                          offset: 1,
                          color: "#f1d56e", // 100% 处的颜色
                        },
                      ],
                    };
                  } else if (params.dataIndex == 102) {
                    color = {
                      type: "linear",
                      x: 0,
                      y: 0,
                      x2: 1,
                      y2: 0,
                      colorStops: [
                        {
                          offset: 0,
                          color: "#2f5d69", // 0% 处的颜色
                        },
                        {
                          offset: 1,
                          color: "#73dd8d", // 100% 处的颜色
                        },
                      ],
                    };
                  } else {
                    color = {
                      type: "linear",
                      x: 0,
                      y: 0,
                      x2: 1,
                      y2: 0,
                      colorStops: [
                        {
                          offset: 0,
                          color: "#204694", // 0% 处的颜色
                        },
                        {
                          offset: 1,
                          color: "#4fa6f1", // 100% 处的颜色
                        },
                      ],
                    };
                  }
                  return color;
                },
              },
            },
            label: {
              normal: {
                show: true,
                position: "left",
                formatter: "{b}",
                textStyle: {
                  color: "#8baac8",
                  fontSize: 14,
                },
              },
            },
            data: category,
            z: 1,
            animationEasing: "elasticOut",
          },
          {
            // 分隔
            type: "pictorialBar",
            itemStyle: {
              normal: {
                color: "#061348",
              },
            },
            symbolRepeat: "fixed",
            symbolMargin: 6,
            symbol: "rect",
            symbolClip: true,
            symbolSize: [1, 21],
            symbolPosition: "start",
            symbolOffset: [1, -1],
            symbolBoundingData: total,
            data: category,
            z: 2,
            animationEasing: "elasticOut",
          },
          {
            // 外边框
            type: "pictorialBar",
            symbol: "rect",
            symbolBoundingData: total,
            itemStyle: {
              normal: {
                color: "none",
              },
            },
            label: {
              normal: {
                formatter: (params) => {
                  var text;
                  if (params.dataIndex == 1) {
                    text = "{f|  " + params.data + "}";
                  } else if (params.dataIndex == 2) {
                    text = "{f|  " + params.data + "}";
                  } else if (params.dataIndex == 3) {
                    text = "{f|  " + params.data + "}";
                  } else {
                    text = "{f|  " + params.data + "}";
                  }
                  return text;
                },
                rich: {
                  a: {
                    color: "red",
                  },
                  b: {
                    color: "blue",
                  },
                  c: {
                    color: "yellow",
                  },
                  d: {
                    color: "green",
                  },
                  f: {
                    color: "#609be2",
                    fontSize: 16,
                  },
                },
                position: "right",
                distance: 0, // 向右偏移位置
                show: true,
              },
            },
            data: datas,
            z: 0,
            animationEasing: "elasticOut",
          },
          {
            name: "外框",
            type: "bar",
            barGap: "-120%", // 设置外框粗细
            data: [total, total, total],
            barWidth: 25,
            itemStyle: {
              normal: {
                color: "transparent", // 填充色
                barBorderColor: "#1C4B8E", // 边框色
                barBorderWidth: 0, // 边框宽度
                // barBorderRadius: 0, //圆角半径
                label: {
                  // 标签显示位置
                  show: false,
                  position: "top", // insideTop 或者横向的 insideLeft
                },
              },
            },
            z: 0,
          },
        ],
      };
      myChart.setOption(option);

      window.addEventListener("resize", () => {
        myChart.resize();
      });
    },
    barChartInit() {
      var myChart = echarts.init(document.getElementById("bar"));
      const option = {
        grid: {
          top: "20%",
          left: "13%",
          right: "13%",
          bottom: "10%",
        },

        label: {
          show: false,
        },
        // tooltip: {
        //   trigger: "axis",
        //   axisPointer: {
        //     type: "shadow",
        //   },
        // },

        legend: {
          show: true,
          left: "60%",
          textStyle: {
            color: "#fff", //legend字体颜色
          },
        },
        xAxis: {
          type: "category",
          axisTick: { show: false },
          data: ["指标1", "指标2", "指标3", "指标4", "指标5", "指标6"],
          axisLabel: {
            show: true,
            textStyle: {
              color: "#fff",
            },
          },
        },

        yAxis: [
          {
            name: "单位:指数",
            nameTextStyle: {
              color: "#fff",
              padding: 20,
            },
            type: "value",
            splitLine: {
              show: false,
            },
            axisLabel: {
              show: true,
              textStyle: {
                color: "#fff",
              },
            },
          },
        ],
        series: [
          {
            name: "收入",
            type: "bar",
            barGap: "30%",
            barWidth: "20%",
            borderColor: "red",
            borderWidth: 1,

            tooltip: {
              valueFormatter: function (value) {
                return value + "%";
              },
            },
            emphasis: {
              focus: "series",
            },
            itemStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                {
                  offset: 0,
                  color: "rgba(22,75,247,0.1)",
                },
                {
                  offset: 1,
                  color: "rgba(22,75,247,0.1)",
                },
              ]),
              borderColor: "#385bbe",
              borderWidth: 2,
            },
            data: [98, 80, 62, 100, 80, 62],
          },
          {
            name: "支出",

            type: "bar",
            barGap: "30%",
            barWidth: "20%",
            borderColor: "red",
            borderWidth: 1,

            tooltip: {
              valueFormatter: function (value) {
                return value + "%";
              },
            },
            emphasis: {
              focus: "series",
            },
            itemStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                {
                  offset: 0,
                  color: "rgba(22,75,247,0.1)",
                },
                {
                  offset: 1,
                  color: "rgba(22,75,247,0.1)",
                },
              ]),
              borderColor: "#c98a48",
              borderWidth: 2,
            },
            data: [80, 62, 80, 100, 98, 88],
          },
        ],
      };

      myChart.setOption(option);

      window.addEventListener("resize", () => {
        myChart.resize();
      });
    },
    lastChartInit() {
      // var myChart = echarts.init(document.getElementById("last"));
      // myChart.setOption(option);
      // window.addEventListener("resize", () => {
      //   myChart.resize();
      // });
    },
    lineChart() {
      var myChart = echarts.init(document.getElementById("line"));
      const option = {
        grid: {
          top: "20%",
          left: "17%",
          right: "13%",
          bottom: "10%",
        },
        legend: {
          data: ["收入指数", "支出指数"],
          top: "5%",
          left: "60%",
          orient: "horizontal",
          textStyle: {
            color: "#fff", //legend字体颜色
          },
        },
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "shadow",
          },
        },
        xAxis: {
          type: "category",
          axisTick: { show: true },
          data: [
            "2015",
            "2016",
            "2017",
            "2018",
            "2019",
            "2020",
            "2021",
            "2022",
          ],
          axisLabel: {
            show: true,
            textStyle: {
              color: "#fff",
            },
          },
        },

        yAxis: {
          name: "单位：指数",
          nameTextStyle: {
            color: "#fff",
            padding: 20,
          },
          splitLine: {
            show: false,
          },
          axisLabel: {
            show: true,
            textStyle: {
              color: "#fff",
            },
          },
        },

        series: [
          {
            name: "收入指数",
            type: "line",
            symbol: "none",
            itemStyle: {
              normal: {
                color: "#4b94cb",
                lineStyle: {
                  color: "#4b94cb",
                },
              },
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                {
                  offset: 0,
                  color: "rgba(99, 195, 237,0.8)", //靠上方的透明颜色
                },
                {
                  offset: 1,
                  color: "rgba(0, 0, 84,0.3)", //靠下方的透明颜色
                },
              ]),
            },
            data: [120, 97, 38, 110, 62, 100, 65, 95],
          },
          {
            name: "支出指数",
            type: "line",
            symbol: "none",
            itemStyle: {
              normal: {
                color: "#4b94cb",
                lineStyle: {
                  color: "#5abf9d",
                },
              },
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                {
                  offset: 0,
                  color: "rgba(91, 191, 158,0.8)", //靠上方的透明颜色
                },
                {
                  offset: 1,
                  color: "rgba(0, 0, 84,0.3)", //靠下方的透明颜色
                },
              ]),
            },
            data: [120, 57, 68, 120, 70, 100, 95, 95],
          },
        ],
      };

      myChart.setOption(option);

      window.addEventListener("resize", () => {
        myChart.resize();
      });
    },
    getScale() {
      let { width, height } = this;
      let wh = window.innerHeight / height;
      let ww = window.innerWidth / width;
      return ww < wh ? ww : wh;
    },
    setScale() {
      this.scale = this.getScale();
      if (this.$refs.ScaleBox) {
        this.$refs.ScaleBox.style.setProperty("--scale", this.scale);
      }
    },
    debounce(fn, delay) {
      let delays = delay || 500;
      let timer;
      return function () {
        let th = this;
        let args = arguments;
        if (timer) {
          clearTimeout(timer);
        }
        timer = setTimeout(function () {
          timer = null;
          fn.apply(th, args);
        }, delays);
      };
    },
  },
};
</script>

<style scoped lang="scss">
/deep/.el-input__inner {
  background-color: rgba(0, 222, 255, 0.24);
  color: #fff;
  width: 144px;
  height: 38px;
  box-shadow: 0px 0px 16px 0px rgba(131, 219, 255, 0.2) inset;
  border-radius: 4px;
  border: none;
}
/deep/.el-form-item__label {
  color: #fff;
}
/deep/.el-input {
  width: 180px;
}

/deep/.el-button--primary {
  background: linear-gradient(0deg, #17e0fe, #0783cf);
}
/deep/.el-button {
  color: #fff;
  background-color: rgba(0, 222, 255, 0.24);
  box-shadow: 0px 0px 16px 0px rgba(131, 219, 255, 0.2) inset;
  border-radius: 4px;
  border: none;
}
/deep/.el-table tbody tr:hover > td {
  background: #0e183e !important;
}
/deep/.el-table {
  color: #00ffff;
  border: none;
  margin: 0;
}
/deep/table {
  width: 1232px !important;
}
/deep/.el-table tr {
  background-color: #071844;
}
/deep/.el-table td.el-table__cell {
  border: none;
}
/deep/.el-table__header {
  width: 1232px;
}
// 去掉表格单元格边框
/deep/.customer-table th {
  border: none;
}
/deep/.customer-table td,
.customer-table th.is-leaf {
  border: none;
}

// 头部边框
/deep/.customer-table thead tr th.is-leaf {
  border: none;
}
/deep/.customer-table thead tr th:nth-last-of-type(2) {
  border: none;
}
// 表格最外层边框-底部边框
/deep/.el-table--border::after,
.el-table--group::after {
  width: 0;
}
/deep/.customer-table::before {
  width: 0;
}
/deep/.customer-table .el-table__fixed-right::before,
.el-table__fixed::before {
  width: 0;
}

::v-deep .el-table__row.warning-row {
  background-color: #0e2550;
}
.form-search {
  margin: 20px 0 30px;
}
#ScaleBox {
  --scale: 1;
}
.ScaleBox {
  padding: 15px;
  position: absolute;
  transform: scale(var(--scale)) translate(-50%, -50%);
  display: flex;
  flex-direction: column;
  transform-origin: 0 0;
  left: 50%;
  top: 50%;
  transition: 0.3s;
  z-index: 999;
  background-color: #000337;
}
.page-content {
  padding: 20px 0;
}
.top {
  height: 80px;
  background: #000337;
  background: url("../assets/sanjiang/形状\ 14@2x.png") 62% 100% no-repeat;
  font-family: Source Han Sans CN;
  position: relative;
  .top-title {
    display: inline-block;
    width: 188px;
    height: 70px;
    margin-top: 25px;
    line-height: 100px;
    text-align: center;
    color: #2e9eff;
    background: url("../assets/sanjiang/1@2x.png") 50% 100% no-repeat;
  }
  .bg-choose{
    background: url("../assets/sanjiang/1@2x(1).png") 50% 100% no-repeat;
    color: #fff;
  }
  .top-text {
    position: absolute;
    top: -15px;
    left: 750px;
    background-image: -webkit-linear-gradient(bottom, #fff, #61f4f9);
    margin-left: 80px;
    width: 300px;
    height: 40px;
    margin-top: 40px;
    font-size: 32px;
    display: inline-block;
    font-weight: bold;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    overflow: hidden;
  }
  .left-50 {
    margin-left: 450px;
  }
  .top-right {
    margin-left: 20px;
  }
}
.right-two-box {
  vertical-align: top;
  width: 200px;
  display: inline-block;
  height: 300px;
  margin: 20px 0 0 10px;
  .two-title {
    color: #b9cadb;
    margin-bottom: 20px;
    .titles {
      width: 12px;
      display: inline-block;
      height: 12px;
      background-color: #428bd2;
      margin-right: 12px;
    }
    .nums {
      .num {
        font-size: 30px;
        margin-left: 30px;
        font-weight: 600;
      }
      .color1 {
        background-image: -webkit-linear-gradient(top, #fff, #428bd2);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
      }
      .color2 {
        background-image: -webkit-linear-gradient(top, #fff, #65b24e);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
      }
      .color3 {
        background-image: -webkit-linear-gradient(top, #fff, #e4893d);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
      }
      .color4 {
        background-image: -webkit-linear-gradient(top, #fff, #62cbec);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
      }
    }
  }
}

.chart {
  background: url("../assets/sanjiang/组\ 7@2x\(1\).png") no-repeat;
  background-size: cover;
  background-size: 100% 98%;
  width: 100%;
  height: 480px;
  .title {
    font-weight: 600;
    text-align: center;
    font-size: 20px;
    line-height: 70px;
    background-image: linear-gradient(
      92deg,
      #000054 35%,
      #b1f5fa 48.8525390625%,
      #75c8fa 100%
    );
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }
}
.mt-40 {
  margin-top: 35px;
}
.ml-10 {
  margin-left: 20px !important;
}
.chart-center {
  background: url("../assets/sanjiang/组\ 24@2x\(5\).png") no-repeat;
  background-size: 100% 97%;
  width: 100%;
  height: 480px;
  .title {
    font-weight: 600;
    text-align: center;
    font-size: 20px;
    line-height: 70px;
    background-image: linear-gradient(
      92deg,
      #000054 35%,
      #b1f5fa 48.8525390625%,
      #75c8fa 100%
    );
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }
}
#bar {
  height: 350px;
}
#line {
  height: 350px;
}

#last {
  height: 200px;
}
#eightChart {
  height: 350px;
}
#rate {
  display: inline-block;
  width: 350px;
  height: 350px;
}
#oneChart {
  height: 350px;
  display: inline-block;
  width: 230px;
}
#oneChart2 {
  display: inline-block;
  height: 350px;
  margin-top: 40px;
  width: 230px;
}
.five {
  position: relative;
  img {
    position: absolute;
    top: 200px;
    left: 60px;
    width: 350px;
  }
}
.bottom-title {
  color: #fff;
  text-align: center;
  margin-top: 15px;
  span {
    margin-right: 15px;
    background: linear-gradient(
      0deg,
      rgba(51, 214, 255, 0.3),
      rgba(51, 229, 255, 0.8)
    );
    border-radius: 10px;
    padding: 5px 10px;
    font-size: 14px;
    cursor: pointer;
  }
  span:last-child {
    background: linear-gradient(
      0deg,
      rgba(255, 226, 101, 0.6),
      rgba(255, 156, 0, 0.6)
    );
  }
}
.three-box {
  text-align: center;
  img {
    margin-top: -15px;
  }
}
.bg {
  background: url("../assets/sanjiang/组\ 15@2x\(1\).png") no-repeat !important;
  background-size: 100% 100% !important;
}
.content-text {
  color: #9cf5fb;
  .five {
    font-weight: 600;
    font-size: 30px;
    margin-right: 5px;
  }
  .span-box {
    margin: 0 50px;
  }
  .span-box2 {
    margin: 0 44px;
    color: #92a9c5;
  }
}
.content {
  padding: 10px;
  background: url("../assets/sanjiang/组\ 15@2x.png") no-repeat;
  background-size: 100% 100%;
  box-sizing: border-box;
  width: 260px;
  height: 170px;
  display: inline-block;
  margin: 20px 0 0 50px;
  text-align: center;
  .content-title {
    margin-top: 20px;
    font-size: 38px;
    color: #9cf6fb;
    font-weight: 500;
  }
  .content-content {
    margin-top: 15px;
    font-size: 16px;
    color: #a9b9cf;
    span {
      font-size: 14px;
    }
  }
  .content-bottom {
    width: 100px;
    height: 20px;
    line-height: 20px;
    margin-top: 15px;
    text-align: center;
    font-size: 12px;
    color: #3dff00;
    box-shadow: 0px 12px 7px 0px rgba(16, 85, 216, 0.35) inset;
    border: 1px solid #209bd3;
    border-radius: 100px;
    img {
      width: 18px;
    }
  }
}
.top-box {
  padding: 30px 50px;
  .line {
    display: inline-block;
    width: 1px;
    height: 100px;
    margin: 0 45px;
    background: linear-gradient(
      0deg,
      rgba(255, 255, 255, 0) 0%,
      rgba(70, 226, 255, 0.97) 50%,
      rgba(255, 255, 255, 0) 100%
    );
  }
  .top-content {
    width: 300px;
    font-size: 16px;
    margin-bottom: 20px;
    display: inline-block;
    line-height: 32px;
    color: #fff;
    height: 70px;

    .top-img {
      display: block;
      width: 60px;
    }
    .apply {
      font-size: 13px !important;
    }
    .num {
      font-size: 30px;
      font-weight: 600;
      background: linear-gradient(0deg, #2bb3ff 0%, #38e7ee 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    .content-bottom {
      width: 100px;
      height: 20px;
      line-height: 20px;
      margin-top: 15px;
      text-align: center;
      font-size: 12px;
      color: #3dff00;
      border: 1px solid #209bd3;
      border-radius: 100px;
      box-shadow: 0px 12px 7px 0px rgba(16, 85, 216, 0.35) inset;
      img {
        width: 18px;
      }
    }
  }
}

.right-box {
  width: 150px;
  font-size: 14px;
  color: #fff;
  float: right;
  margin-top: 25px;
  line-height: 18px;
  cursor: pointer;
  .right-content {
    // padding: 35px 20px;
    img {
      display: block;
      width: 20px;
      margin-top: 7px;
    }
    .num {
      text-align: left;
    }
    .apply {
      text-align: left;
    }
  }
}
</style>
