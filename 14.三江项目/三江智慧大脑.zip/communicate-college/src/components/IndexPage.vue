<template>
  <div
    class="ScaleBox"
    ref="ScaleBox"
    :style="{
      width: width + 'px',
      height: height + 'px',
    }"
  >
    <el-row>
      <el-col :span="24">
        <div class="top">
          <div class="text">
            <img src="../assets/college/形状 22 拷贝 11@2x.png" alt="">
          <span >通讯学院DSPV7</span>
          <img src="../assets/college/形状 22 拷贝 9@2x.png" alt="">
          </div>
          <div class="right-box right">
            <div class="right-content">
              <el-col :span="5"><img src="../assets/college/矩形 11@2x.png" /></el-col>
              <el-col :span="14">
                <div>
                  <div class="num" style="margin: 6px 0 0 0px">退出</div>
                </div>
              </el-col>
            </div>
          </div>
          <div class="right-box">
            <div class="right-content">
              <el-col :span="5"
                ><img src="../assets/college/圆角矩形 2@2x.png"
              /></el-col>
              <el-col :span="14">
                <div>
                  <div class="num">Admin</div>
                  <div class="apply">欢迎你使用！</div>
                </div>
              </el-col>
            </div>
          </div>
        </div>
      </el-col>
    </el-row>
    <div class="page-content">
      <el-row :gutter="20">
        <el-col :span="4"
          ><div class="top-box">
            <div class="top-content">
              <el-col :span="10"
                ><img src="../assets/college/组 19@2x(2).png"
              /></el-col>
              <el-col :span="14">
                <div>
                  <div class="num">13213 <span>个</span></div>
                  <div class="apply">
                    <div class="cal"></div>
                    申请数量
                  </div>
                </div>
              </el-col>
            </div>
          </div>
        </el-col>
        <el-col :span="4"
          ><div class="top-box">
            <div class="top-content">
              <el-col :span="10"
                ><img src="../assets/college/组 19@2x(3).png"
              /></el-col>
              <el-col :span="14">
                <div>
                  <div class="num">13213 <span>个</span></div>
                  <div class="apply">
                    <div class="cal" style="background-color: #ee7ddd"></div>
                    未审批数量
                  </div>
                </div>
              </el-col>
            </div>
          </div>
        </el-col>
        <el-col :span="4"
          ><div class="top-box">
            <div class="top-content">
              <el-col :span="10"><img src="../assets/college/组19@2x(4).png" /></el-col>
              <el-col :span="14">
                <div>
                  <div class="num">13213 <span>个</span></div>
                  <div class="apply">
                    <div class="cal" style="background-color: #7532f5"></div>
                    已审批数量
                  </div>
                </div>
              </el-col>
            </div>
          </div>
        </el-col>
        <el-col :span="4"
          ><div class="top-box">
            <div class="top-content">
              <el-col :span="10"><img src="../assets/college/组19@2x(5).png" /></el-col>
              <el-col :span="14">
                <div>
                  <div class="num">13213 <span>个</span></div>
                  <div class="apply">
                    <div class="cal" style="background-color: #f4b654"></div>
                    已完成开发数量
                  </div>
                </div>
              </el-col>
            </div>
          </div>
        </el-col>
        <el-col :span="4"
          ><div class="top-box">
            <div class="top-content">
              <el-col :span="10"><img src="../assets/college/组19@2x(6).png" /></el-col>
              <el-col :span="14">
                <div>
                  <div class="num">13213 <span>个</span></div>
                  <div class="apply">
                    <div class="cal" style="background-color: #7532f5"></div>
                    未完成开发数量
                  </div>
                </div>
              </el-col>
            </div>
          </div>
        </el-col>
        <el-col :span="4"
          ><div class="top-box">
            <div class="top-content">
              <el-col :span="10"><img src="../assets/college/组19@2x(7).png" /></el-col>
              <el-col :span="14">
                <div>
                  <div class="num">13213 <span>个</span></div>
                  <div class="apply">
                    <div class="cal" style="background-color: #f4b654"></div>
                    今日新增数量
                  </div>
                </div>
              </el-col>
            </div>
          </div>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="6">
          <div class="center-box">
            <div class="title">
              <div class="line"></div>
              <div class="font">数据资源统计</div>
            </div>
            <div id="bar" style="height: 250px"></div>
          </div>
        </el-col>
        <el-col :span="6"
          ><div class="center-box">
            <div class="title">
              <div class="line"></div>
              <div class="font">服务调用统计</div>
            </div>
            <div id="line1" style="height: 250px"></div></div
        ></el-col>
        <el-col :span="6"
          ><div class="center-box">
            <div class="title">
              <div class="line"></div>
              <div class="font">应用使用统计</div>
            </div>
            <div id="line2" style="height: 250px"></div></div
        ></el-col>
        <el-col :span="6">
          <div class="center-box">
            <div class="title">
              <div class="line"></div>
              <div class="font">当日统计</div>
              <div class="center-content">
                <div class="depart">
                  <img src="../assets/college/组 18@2x.png" />
                  <div>
                    <span class="num">45 </span>
                    <span class="apply"> 当日服务调用量 </span>
                  </div>
                </div>
                <div class="depart">
                  <img src="../assets/college/组 18@2x(1).png" />
                  <div>
                    <span class="num1">45 </span>
                    <span class="apply"> 异常数量 </span>
                  </div>
                </div>
                <div class="line-day"></div>
                <div class="depart">
                  <img src="../assets/college/组 18@2x.png" />
                  <div>
                    <span class="num">45 </span>
                    <span class="apply"> 当日服务调用量 </span>
                  </div>
                </div>
                <div class="depart">
                  <img src="../assets/college/组 18@2x(1).png" />
                  <div>
                    <span class="num1">45 </span>
                    <span class="apply"> 异常数量 </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="16"
          ><div class="bottom-box">
            <div class="title">
              <div class="line"></div>
              <div class="font">作业执行统计</div>
              <el-form
                ref="form"
                :model="form"
                label-width="80px"
                class="form-search"
              >
                <el-form-item label="关键字：">
                  <el-input v-model="form.name"></el-input>
                  <el-button type="primary" icon="el-icon-search"
                    >查询</el-button
                  >
                  <el-button icon="el-icon-refresh">重置</el-button>
                </el-form-item>
              </el-form>
              <el-table
                :data="tableData"
                class="customer-table"
                :row-class-name="tableRowClassName"
                :header-cell-style="{
                  backgroundColor: '#0b1841',
                  color: '#fff',
                  backgroundImage: 'linear-gradient(180deg, #091e4a, #173c65)',
                }"
                style="width: 100%"
              >
                <el-table-column prop="ID" label="作业ID" align="center">
                </el-table-column>
                <el-table-column prop="name" label="作业名称" align="center">
                </el-table-column>
                <el-table-column prop="num1" label="新增量" align="center">
                </el-table-column>
                <el-table-column prop="num2" label="更新量" align="center">
                </el-table-column>
                <el-table-column prop="num3" label="删除量" align="center">
                </el-table-column>
                <el-table-column prop="num4" label="错误数" align="center">
                </el-table-column>
                <el-table-column prop="num5" label="成功数" align="center">
                </el-table-column>
                <el-table-column prop="num6" label="失败数" align="center">
                </el-table-column>
                <el-table-column prop="date" label="操作" align="center">
                  <template>
                    <div style="color: #d1cb5f">详情</div>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </div></el-col
        >
        <el-col :span="8"
          ><div class="bottom-box">
            <div class="title">
              <div class="line"></div>
              <div class="font">作业执行情况统计</div>
            </div>
            <div id="line3" style="height: 350px"></div></div
        ></el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
import * as echarts from "echarts";

export default {
  name: "ScaleBox",
  data() {
    return {
      scale: "",
      width: 1920,
      height: 1080,
      form: {
        name: "",
      },
      tableData: [
        {
          ID: "1166",
          name: "数据库全量同步",
          num1: "185",
          num2: "0",
          num3: "1",
          num4: "0",
          num5: "0",
          num6: "0",
        },
        {
          ID: "1166",
          name: "数据库全量同步",
          num1: "185",
          num2: "0",
          num3: "1",
          num4: "0",
          num5: "0",
          num6: "0",
        },
        {
          ID: "1166",
          name: "数据库全量同步",
          num1: "185",
          num2: "0",
          num3: "1",
          num4: "0",
          num5: "0",
          num6: "0",
        },
        {
          ID: "1166",
          name: "数据库全量同步",
          num1: "185",
          num2: "0",
          num3: "1",
          num4: "0",
          num5: "0",
          num6: "0",
        },
      ],
    };
  },
  created() {},
  mounted() {
    this.setScale();
    window.addEventListener("resize", this.debounce(this.setScale, 100));
    this.barChartInit();
    this.lineChartInit();
    this.lineChart();
  },
  methods: {
    tableRowClassName({ rowIndex }) {
      if (rowIndex % 2 == 0) {
        return "warning-row";
      } else {
        return "";
      }
    },
    barChartInit() {
      var myChart = echarts.init(document.getElementById("bar"));
      const option = {
        grid: {
          top: "20%",
          left: "10%",
          right: "3%",
          bottom: "10%",
        },
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "shadow",
          },
        },
        legend: {
          data: ["系统", "数据库", "文件"],
          textStyle: {
            color: "#fff", //legend字体颜色
          },
        },
        xAxis: {
          type: "category",
          axisTick: { show: false },
          data: ["资源库", "共享库", "应用库"],
          axisLabel: {
            show: true,
            textStyle: {
              color: "#fff",
            },
          },
        },
        yAxis: [
          {
            type: "value",
            axisLabel: {
              show: true,
              textStyle: {
                color: "#fff",
              },
            },
            splitLine: {
              //  改变轴线颜色
              lineStyle: {
                // 使用深浅的间隔色
                color: ["white"],
                opacity: 0.2,
              },
            },
          },
        ],
        series: [
          {
            name: "系统",
            type: "bar",
            barGap: "30%",
            emphasis: {
              focus: "series",
            },
            itemStyle: {
              normal: {
                color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
                  { offset: 0, color: "#1536f5" },
                  { offset: 1, color: "#4fadf8" },
                ]),
              },
            },
            data: [80, 62, 62],
          },
          {
            name: "数据库",
            type: "bar",
            emphasis: {
              focus: "series",
            },
            itemStyle: {
              normal: {
                color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
                  { offset: 1, color: "#7cf9a2" },
                  { offset: 0, color: "#3f8f8d" },
                ]),
              },
            },
            data: [45, 45, 45],
          },
          {
            name: "文件",
            type: "bar",
            emphasis: {
              focus: "series",
            },
            itemStyle: {
              normal: {
                color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
                  { offset: 1, color: "#4683ae" },
                  { offset: 0, color: "#6344f4" },
                ]),
              },
            },
            data: [39, 39, 39],
          },
        ],
      };
      myChart.setOption(option);

      window.addEventListener("resize", () => {
        myChart.resize();
      });
    },
    lineChartInit() {
      var myChart = echarts.init(document.getElementById("line1"));
      var myChart2 = echarts.init(document.getElementById("line2"));
      const option = {
        grid: {
          top: "20%",
          left: "10%",
          right: "3%",
          bottom: "10%",
        },
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "shadow",
          },
        },
        legend: {
          data: ["XX类1", "XX类2", "XX类3", "XX类4", "XX类5"],
          textStyle: {
            color: "#fff", //legend字体颜色
          },
        },
        xAxis: {
          type: "category",
          axisTick: { show: false },
          data: ["1月", "2月", "3月", "4月"],
          axisLabel: {
            show: true,
            textStyle: {
              color: "#fff",
            },
          },
        },
        yAxis: [
          {
            type: "value",
            axisLabel: {
              show: true,
              textStyle: {
                color: "#fff",
              },
            },
            splitLine: {
              //  改变轴线颜色
              lineStyle: {
                // 使用深浅的间隔色
                color: ["white"],
                opacity: 0.2,
              },
            },
          },
        ],
        series: [
          {
            name: "XX类1",
            symbol: "none",
            type: "line",
            smooth: true,
            barGap: 0,
            emphasis: {
              focus: "series",
            },
            data: [40, 70, 20, 40],
          },
          {
            name: "XX类2",
            type: "line",
            symbol: "none",
            smooth: true,
            emphasis: {
              focus: "series",
            },
            data: [30, 80, 10, 40],
          },
          {
            name: "XX类3",
            type: "line",
            smooth: true,
            symbol: "none",
            emphasis: {
              focus: "series",
            },
            data: [80, 59, 79, 32],
          },
          {
            name: "XX类4",
            type: "line",
            smooth: true,
            symbol: "none",
            emphasis: {
              focus: "series",
            },
            data: [70, 19, 49, 72],
          },
          {
            name: "XX类5",
            type: "line",
            smooth: true,
            symbol: "none",
            emphasis: {
              focus: "series",
            },
            data: [10, 60, 30, 50],
          },
        ],
      };
      myChart.setOption(option);
      myChart2.setOption(option);

      window.addEventListener("resize", () => {
        myChart.resize();
        myChart2.resize();
      });
    },
    lineChart() {
      var myChart = echarts.init(document.getElementById("line3"));
      const option = {
        grid: {
          top: "20%",
          left: "10%",
          right: "3%",
          bottom: "10%",
        },
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "shadow",
          },
        },
        legend: {
          data: ["XX类"],
          textStyle: {
            color: "#fff", //legend字体颜色
          },
        },
        xAxis: {
          type: "category",
          axisTick: { show: false },
          data: [
            "1月",
            "2月",
            "3月",
            "4月",
            "5月",
            "6月",
            "7月",
            "8月",
            "9月",
            "10月",
            "11月",
            "12月",
          ],
          axisLabel: {
            show: true,
            textStyle: {
              color: "#fff",
            },
          },
        },
        yAxis: [
          {
            type: "value",
            axisLabel: {
              show: true,
              textStyle: {
                color: "#fff",
              },
            },
            splitLine: {
              //  改变轴线颜色
              lineStyle: {
                // 使用深浅的间隔色
                color: ["white"],
                opacity: 0.2,
              },
            },
          },
        ],
        series: [
          {
            name: "XX类",
            symbol: "none",
            type: "line",
            smooth: true,
            barGap: 0,
            itemStyle: {
              normal: {
                color: "#e350a2",
              },
            },
            emphasis: {
              focus: "series",
            },
            data: [80, 70, 20, 70, 10, 47, 50, 10, 20, 50, 80, 10],
          },
        ],
      };
      myChart.setOption(option);

      window.addEventListener("resize", () => {
        myChart.resize();
      });
    },
    getScale() {
      let { width, height } = this;
      let wh = window.innerHeight / height;
      let ww = window.innerWidth / width;
      return ww < wh ? ww : wh;
    },
    setScale() {
      this.scale = this.getScale();
      if (this.$refs.ScaleBox) {
        this.$refs.ScaleBox.style.setProperty("--scale", this.scale);
      }
    },
    debounce(fn, delay) {
      let delays = delay || 500;
      let timer;
      return function () {
        let th = this;
        let args = arguments;
        if (timer) {
          clearTimeout(timer);
        }
        timer = setTimeout(function () {
          timer = null;
          fn.apply(th, args);
        }, delays);
      };
    },
  },
};
</script>

<style scoped lang="scss">
/deep/.el-input__inner {
  background-color: rgba(0, 222, 255, 0.24);
  color: #fff;
  width: 144px;
  height: 38px;
  box-shadow: 0px 0px 16px 0px rgba(131, 219, 255, 0.2) inset;
  border-radius: 4px;
  border: none;
}
/deep/.el-form-item__label {
  color: #fff;
}
/deep/.el-input {
  width: 180px;
}

/deep/.el-button--primary {
  background: linear-gradient(0deg, #17e0fe, #0783cf);
}
/deep/.el-button {
  color: #fff;
  background-color: rgba(0, 222, 255, 0.24);
  box-shadow: 0px 0px 16px 0px rgba(131, 219, 255, 0.2) inset;
  border-radius: 4px;
  border: none;
}
/deep/.el-table tbody tr:hover > td {
  background: #0e183e !important;
}
/deep/.el-table {
  color: #00ffff;
  border: none;
  margin: 0;
}
/deep/table {
  width: 1232px !important;
}
/deep/.el-table tr {
  background-color: #071844;
}
/deep/.el-table td.el-table__cell {
  border: none;
}
/deep/.el-table__header {
  width: 1232px;
}
// 去掉表格单元格边框
/deep/.customer-table th {
  border: none;
}
/deep/.customer-table td,
.customer-table th.is-leaf {
  border: none;
}

// 头部边框
/deep/.customer-table thead tr th.is-leaf {
  border: none;
}
/deep/.customer-table thead tr th:nth-last-of-type(2) {
  border: none;
}
// 表格最外层边框-底部边框
/deep/.el-table--border::after,
.el-table--group::after {
  width: 0;
}
/deep/.customer-table::before {
  width: 0;
}
/deep/.customer-table .el-table__fixed-right::before,
.el-table__fixed::before {
  width: 0;
}

::v-deep .el-table__row.warning-row {
  background-color: #0e2550;
}
.form-search {
  margin: 20px 0 30px;
}
#ScaleBox {
  --scale: 1;
}
.ScaleBox {
  padding: 15px;
  position: absolute;
  transform: scale(var(--scale)) translate(-50%, -50%);
  display: flex;
  flex-direction: column;
  transform-origin: 0 0;
  left: 50%;
  top: 50%;
  transition: 0.3s;
  z-index: 999;
  background-color: #000337;
}
.page-content {
  padding: 20px 0;
}
.top {
  height: 80px;
  background: #000337;
  box-shadow: 0px 0px 16px 0px rgba(131, 219, 255, 0.3) inset;
  background-image: linear-gradient(-90deg, #020435, #18296a, #020435);
  text-align: center;
  font-size: 40px;
  font-family: Source Han Sans CN;
  font-weight: bold;
  color: #00ffff;
  line-height: 80px;
  opacity: 0.8;
  .text {
    display: inline-block;
    margin-left: 300px;
    span{
      margin: 0 50px;
    }
    img{
      width: 300px;
    }
  }
}
.right {
  padding-top: 5px;
}
.right-box {
  width: 150px;
  font-size: 14px;
  color: #fff;
  float: right;
  margin-top: 25px;
  line-height: 18px;
  cursor: pointer;
  .right-content {
    // padding: 35px 20px;
    img {
      display: block;
      width: 20px;
      margin-top: 7px;
    }
    .num {
      text-align: left;
    }
    .apply {
      text-align: left;
    }
  }
}
.top-box {
  background: #000337;
  border: 1px solid #4cbaff;
  box-shadow: 0px 0px 120px 0px rgba(131, 219, 255, 0.3) inset;
  border-radius: 6px;
  height: 130px;
  margin-bottom: 20px;
  font-size: 16px;
  color: #fff;
  line-height: 32px;
  .top-content {
    padding: 35px 20px;
    img {
      display: block;
      width: 60px;
    }
    .num {
      font-size: 30px;
      font-weight: 600;
      span {
        font-size: 16px;
      }
    }
    .apply {
      .cal {
        width: 12px;
        height: 12px;
        border-radius: 12px;
        background-color: #75fbfd;
        display: inline-block;
      }
    }
  }
}

.center-box {
  background-color: #fff;
  background: #000337;
  border: 1px solid #4cbaff;
  box-shadow: 0px 0px 186px 0px rgba(131, 219, 255, 0.3) inset;
  border-radius: 6px;
  height: 327px;
  padding: 20px;
  box-sizing: border-box;
}
.title {
  overflow: hidden;

  .line {
    display: inline-block;
    width: 4px;
    height: 20px;
    background: #00ffff;
  }
  .font {
    display: inline-block;
    margin-left: 15px;
    font-size: 22px;
    font-weight: 600;
    color: #fff;
  }
}
.bottom-box {
  background-color: #fff;
  background: #000337;
  border: 1px solid #4cbaff;
  box-shadow: 0px 0px 186px 0px rgba(131, 219, 255, 0.3) inset;
  border-radius: 6px;
  height: 444px;
  margin: 20px 0;
  padding: 20px;
  box-sizing: border-box;
}

.center-content {
  .depart {
    width: 50%;
    display: inline-block;
    padding: 15px 40px 10px;
    box-sizing: border-box;
    font-size: 12px;
    text-align: center;
  }
  .line-day {
    width: 100%;
    height: 1px;
    border: 2px solid;
    border-image: linear-gradient(-90deg, #091245, #00ffff, #000337) 10 10;
    border-bottom: none;
  }
  color: #fff;
  .num {
    font-size: 26px;

    color: #00ffff;
  }
  .num1 {
    font-size: 26px;

    color: #ff0d0d;
  }
}
</style>
