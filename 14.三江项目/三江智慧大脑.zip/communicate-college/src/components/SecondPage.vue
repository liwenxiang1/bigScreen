<template>
  <div
    class="ScaleBox"
    ref="ScaleBox"
    :style="{
      width: width + 'px',
      height: height + 'px',
    }"
  >
    <el-row>
      <el-col :span="24">
        <div class="top">
          <div class="top-title">战略管理域</div>
          <div class="top-title">经营管理域</div>
          <div class="top-title">财务管理域</div>
          <div class="top-title">科研生产域</div>
          <div class="top-text">三江万山智慧大脑</div>
          <div class="top-title left-50">质量管理域</div>
          <div class="top-title top-right bg-choose">人力资源域</div>
          <div class="top-title top-right">党群建设域</div>
        </div>
      </el-col>
    </el-row>
    <el-row :gutter="8" class="mt-40">
      <el-col :span="7">
        <div class="chart">
          <div class="title">模块一标题</div>
          <div id="bar"></div>
        </div>
      </el-col>
      <el-col :span="10">
        <div class="chart-center">
          <div class="title">模块二标题</div>
          <div class="top-box">
            <div class="top-content">
              <el-col :span="5"
                ><img class="top-img" src="../assets/sanjiang/组 18@2x(6).png"
              /></el-col>
              <el-col :span="12">
                <div>
                  <div class="num">23.13</div>
                  <div class="apply">净利润（亿元）</div>
                </div>
              </el-col>
              <el-col :span="7">
                <div class="content-bottom">
                  环比 <img src="../assets/sanjiang/icon_jt 拷贝@2x.png" /> 10%
                </div>
              </el-col>
            </div>
            <div class="line"></div>
            <div class="top-content">
              <el-col :span="5"
                ><img class="top-img" src="../assets/sanjiang/组 18@2x(7).png"
              /></el-col>
              <el-col :span="12">
                <div>
                  <div class="num">122.13</div>
                  <div class="apply">利润总额（亿元）</div>
                </div>
              </el-col>
              <el-col :span="7">
                <div class="content-bottom">
                  环比 <img src="../assets/sanjiang/icon_jt 拷贝@2x.png" /> 10%
                </div>
              </el-col>
            </div>
            <div class="top-content">
              <el-col :span="5"
                ><img class="top-img" src="../assets/sanjiang/组 18@2x(8).png"
              /></el-col>
              <el-col :span="12">
                <div>
                  <div class="num">23.13</div>
                  <div class="apply">营业收入（亿元）</div>
                </div>
              </el-col>
              <el-col :span="7">
                <div class="content-bottom">
                  环比 <img src="../assets/sanjiang/icon_jt 拷贝@2x.png" /> 10%
                </div>
              </el-col>
            </div>
            <div class="line"></div>
            <div class="top-content">
              <el-col :span="5"
                ><img class="top-img" src="../assets/sanjiang/组 18@2x(11).png"
              /></el-col>
              <el-col :span="12">
                <div>
                  <div class="num">12.32%</div>
                  <div class="apply">资产证券化率</div>
                </div>
              </el-col>
              <el-col :span="7">
                <div class="content-bottom">
                  环比 <img src="../assets/sanjiang/icon_jt 拷贝@2x.png" /> 10%
                </div>
              </el-col>
            </div>
            <div class="top-content">
              <el-col :span="5"
                ><img class="top-img" src="../assets/sanjiang/组 18@2x(9).png"
              /></el-col>
              <el-col :span="12">
                <div>
                  <div class="num">23.13</div>
                  <div class="apply">研发投入强度</div>
                </div>
              </el-col>
              <el-col :span="7">
                <div class="content-bottom" style="color: red">
                  环比
                  <img src="../assets/sanjiang/矩形 622 拷贝 9@2x.png" /> 10%
                </div>
              </el-col>
            </div>
            <div class="line"></div>
            <div class="top-content">
              <el-col :span="5"
                ><img class="top-img" src="../assets/sanjiang/组 18@2x(10).png"
              /></el-col>
              <el-col :span="12">
                <div>
                  <div class="num">23.13</div>
                  <div class="apply">全员劳动生产率</div>
                </div>
              </el-col>
              <el-col :span="7">
                <div class="content-bottom">
                  环比 <img src="../assets/sanjiang/icon_jt 拷贝@2x.png" /> 10%
                </div>
              </el-col>
            </div>
          </div>
        </div>
      </el-col>
      <el-col :span="7">
        <div class="chart">
          <div class="title">模块三标题</div>
          <div id="line"></div>
        </div>
      </el-col>
    </el-row>
    <el-row :gutter="8">
      <el-col :span="7">
        <div class="chart">
          <div class="title">模块四标题</div>
          <div class="content">
            <div class="content-title">XX问题归零率</div>
            <div class="content-content">XX.XX <span>%</span></div>
            <div class="content-bottom">
              环比 <img src="../assets/sanjiang/icon_jt 拷贝@2x.png" /> 10%
            </div>
          </div>
          <div class="content ml-10">
            <div class="content-title">XX问题归零率</div>
            <div class="content-content">XX.XX <span>%</span></div>
            <div class="content-bottom">
              环比 <img src="../assets/sanjiang/icon_jt 拷贝@2x.png" /> 10%
            </div>
          </div>
          <div class="content">
            <div class="content-title">XX问题归零率</div>
            <div class="content-content">XX.XX <span>%</span></div>
            <div class="content-bottom">
              环比 <img src="../assets/sanjiang/icon_jt 拷贝@2x.png" /> 10%
            </div>
          </div>
          <div class="content ml-10">
            <div class="content-title">XX问题归零率</div>
            <div class="content-content">XX.XX <span>%</span></div>
            <div class="content-bottom">
              环比 <img src="../assets/sanjiang/icon_jt 拷贝@2x.png" /> 10%
            </div>
          </div>
        </div>
      </el-col>
      <el-col :span="10">
        <div class="chart-center five">
          <div class="title">模块五标题</div>
          <img class="dizuo" src="../assets/sanjiang/dizuo.png" />
          <div id="categoryDiv"></div>
        </div>
      </el-col>
      <el-col :span="7">
        <div class="chart">
          <div class="title">模块六标题</div>
          <div class="bottom-title">
            <span>年龄</span>
            <span>学历</span>
          </div>
          <div id="last"></div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import * as echarts from "echarts";
import "echarts-gl";

let boxHeight = 1;
let dataList = [
  {
    name: "某某某产业1",
    value: 31781,
    itemStyle: {
      opacity: 0.7,
      color: "rgba(216, 190, 117)",
    },
  },

  {
    name: "某某某产业2",
    value: 67892,
    itemStyle: {
      opacity: 0.7,
      color: "rgba(201, 139, 87)",
    },
  },

  {
    name: "某某某产业3",
    value: 98737,
    itemStyle: {
      opacity: 0.5,
      color: "RGBA(19, 170, 172)",
    },
  },

  {
    name: "某某某产业4",
    value: 73201,
    itemStyle: {
      opacity: 0.7,
      color: "RGBA(144, 198, 235)",
    },
  },
  {
    name: "某某某产业5",
    value: 53201,
    itemStyle: {
      opacity: 0.7,
      color: "RGBA(153, 212, 243)",
    },
  },
];
// 生成扇形的曲面参数方程，用于 series-surface.parametricEquation
function getParametricEquation(
  startRatio,
  endRatio,
  isSelected,
  isHovered,
  k,
  height
) {
  // 计算
  let midRatio = (startRatio + endRatio) / 2;

  let startRadian = startRatio * Math.PI * 2;
  let endRadian = endRatio * Math.PI * 2;
  let midRadian = midRatio * Math.PI * 2;

  // 如果只有一个扇形，则不实现选中效果。
  if (startRatio === 0 && endRatio === 1) {
    isSelected = false;
  }

  // 通过扇形内径/外径的值，换算出辅助参数 k（默认值 1/3）
  k = typeof k !== "undefined" ? k : 1 / 3;

  // 计算选中效果分别在 x 轴、y 轴方向上的位移（未选中，则位移均为 0）
  let offsetX = isSelected ? Math.cos(midRadian) * 0.1 : 0;
  let offsetY = isSelected ? Math.sin(midRadian) * 0.1 : 0;

  // 计算高亮效果的放大比例（未高亮，则比例为 1）
  let hoverRate = isHovered ? 1.05 : 1;

  // 返回曲面参数方程
  return {
    u: {
      min: -Math.PI,
      max: Math.PI * 3,
      step: Math.PI / 32,
    },

    v: {
      min: 0,
      max: Math.PI * 2,
      step: Math.PI / 20,
    },

    x: function (u, v) {
      if (u < startRadian) {
        return (
          offsetX + Math.cos(startRadian) * (1 + Math.cos(v) * k) * hoverRate
        );
      }
      if (u > endRadian) {
        return (
          offsetX + Math.cos(endRadian) * (1 + Math.cos(v) * k) * hoverRate
        );
      }
      return offsetX + Math.cos(u) * (1 + Math.cos(v) * k) * hoverRate;
    },

    y: function (u, v) {
      if (u < startRadian) {
        return (
          offsetY + Math.sin(startRadian) * (1 + Math.cos(v) * k) * hoverRate
        );
      }
      if (u > endRadian) {
        return (
          offsetY + Math.sin(endRadian) * (1 + Math.cos(v) * k) * hoverRate
        );
      }
      return offsetY + Math.sin(u) * (1 + Math.cos(v) * k) * hoverRate;
    },

    z: function (u, v) {
      if (u < -Math.PI * 0.5) {
        return Math.sin(u);
      }
      if (u > Math.PI * 2.5) {
        return Math.sin(u);
      }
      return Math.sin(v) > 0 ? 1 * height : -1;
    },
  };
}

// 生成模拟 3D 饼图的配置项
function getPie3D(pieData, internalDiameterRatio) {
  let series = [];
  let sumValue = 0;
  let startValue = 0;
  let endValue = 0;
  let legendData = [];
  let k =
    typeof internalDiameterRatio !== "undefined"
      ? (1 - internalDiameterRatio) / (1 + internalDiameterRatio)
      : 1 / 3;

  // 为每一个饼图数据，生成一个 series-surface 配置
  for (let i = 0; i < pieData.length; i++) {
    sumValue += pieData[i].value;

    let seriesItem = {
      name:
        typeof pieData[i].name === "undefined" ? `series${i}` : pieData[i].name,
      type: "surface",
      parametric: true,
      wireframe: {
        show: false,
      },
      pieData: pieData[i],
      pieStatus: {
        selected: false,
        hovered: false,
        k: k,
      },
    };

    if (typeof pieData[i].itemStyle != "undefined") {
      let itemStyle = {};

      typeof pieData[i].itemStyle.color != "undefined"
        ? (itemStyle.color = pieData[i].itemStyle.color)
        : null;
      typeof pieData[i].itemStyle.opacity != "undefined"
        ? (itemStyle.opacity = pieData[i].itemStyle.opacity)
        : null;

      seriesItem.itemStyle = itemStyle;
    }
    series.push(seriesItem);
  }

  // 使用上一次遍历时，计算出的数据和 sumValue，调用 getParametricEquation 函数，
  // 向每个 series-surface 传入不同的参数方程 series-surface.parametricEquation，也就是实现每一个扇形。
  let linesSeries = [];
  for (let i = 0; i < series.length; i++) {
    endValue = startValue + series[i].pieData.value;
    console.log(series[i]);
    series[i].pieData.startRatio = startValue / sumValue;
    series[i].pieData.endRatio = endValue / sumValue;
    series[i].parametricEquation = getParametricEquation(
      series[i].pieData.startRatio,
      series[i].pieData.endRatio,
      false,
      false,
      k,
      series[i].pieData.value
    );

    startValue = endValue;

    let midRadian =
      (series[i].pieData.endRatio + series[i].pieData.startRatio) * Math.PI;
    let posX = Math.cos(midRadian) * (1 + Math.cos(Math.PI / 2));
    let posY = Math.sin(midRadian) * (1 + Math.cos(Math.PI / 2));
    let posZ = Math.log(Math.abs(series[i].pieData.value + 1)) * 0.1;
    let endPosArr = [posX * 0.85, posY, posZ];
    linesSeries.push(
      {
        type: "line3D",
        lineStyle: {
          color: "rgba(50, 158, 208, 1)",
          type: "d",
        },
        data: [[posX, posY, posZ], endPosArr],
      },
      {
        type: "scatter3D",
        label: {
          show: false,
          position: "right",
          distance: posZ * 45,
          // formatter: '{b}/n{c}',
          formatter: (params) => {
            if (params.seriesName !== "mouseoutSeries") {
              return (
                "{a|" +
                series[i].pieData.value +
                "}" +
                "\n {b|" +
                params.name +
                "}"
              );
            }
          },
          rich: {
            a: {
              color: "#84F2FF",
              fontSize: 14,
              fontWeight: "bolder", //字体加粗
            },
            b: {
              color: "#ffffff",
              fontSize: 14,
              fontWeight: "bolder", //字体加粗
            },
          },
          fontSize: 14,
        },
        // symbol:img,
        symbolSize: 0,
        data: [
          {
            name: series[i].name,
            value: endPosArr,
          },
        ],
      }
    );

    legendData.push(series[i].name);
  }
  series = series.concat(linesSeries);
  let nums = dataList.map((obj) => obj.value);
  let maxNum = Math.max(...nums);
  boxHeight = 80 / maxNum;
  // 准备待返回的配置项，把准备好的 legendData、series 传入。
  let option = {
    tooltip: {
      formatter: (params) => {
        if (params.seriesName !== "mouseoutSeries") {
          return `${
            params.seriesName
          }<br/><span style="display:inline-block;margin-right:5px;border-radius:10px;width:10px;height:10px;"></span>${
            option.series[params.seriesIndex].pieData.value
          }`;
        }
      },
      backgroundColor: "RGBA(7, 0, 84, .5)", //设置背景图片 rgba格式
      textStyle: {
        color: "#ffffff", //设置文字颜色
      },
    },
    legend: {
      data: legendData,
      orient: "vertical",
      x: "60%",
      y: "center",
      itemGap: 40,
      textStyle: {
        color: "#fff",
        fontSize: 14,
        rich: {
          // 给labelName添加样式
          labelName: {
            color: "#4ca5c2",
            fontSize: 14
          },
        },
      },
      itemHeight: 15,
      formatter(label) {
        return (
          label + `{labelName|    XXX.X亿     28%}`
        );
      },
    },
    xAxis3D: {
      min: -1,
      max: 1,
    },
    yAxis3D: {
      min: -1,
      max: 1,
    },
    zAxis3D: {
      min: -1,
      max: 1,
    },
    grid3D: {
      show: false,
      boxHeight: boxHeight,
      top: "10%",
      bottom: 0,
      left: "-20%",
      viewControl: {
        distance: 160,
        alpha: 25,
        beta: 130,
      },
    },
    series: series,
  };
  return option;
}

const option = getPie3D(dataList, 1.5);
getPie3D(dataList, 1.5);
const categoryInit = () => {
  let pie3D = echarts.init(document.getElementById("categoryDiv"));
  pie3D.setOption(option);
};
export default {
  name: "ScaleBox",
  data() {
    return {
      scale: "",
      width: 1920,
      height: 1080,
    };
  },
  created() {},
  mounted() {
    this.setScale();
    window.addEventListener("resize", this.debounce(this.setScale, 100));
    this.barChartInit();
    this.lastChartInit();
    this.lineChart();
    categoryInit();
  },
  methods: {
    tableRowClassName({ rowIndex }) {
      if (rowIndex % 2 == 0) {
        return "warning-row";
      } else {
        return "";
      }
    },
    barChartInit() {
      var myChart = echarts.init(document.getElementById("bar"));
      const option = {
        grid: {
          top: "20%",
          left: "13%",
          right: "13%",
          bottom: "10%",
        },

        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "shadow",
          },
        },
        legend: {
          data: ["次数", "占比"],
          textStyle: {
            color: "#fff", //legend字体颜色
          },
        },
        xAxis: {
          type: "category",
          axisTick: { show: false },
          data: ["指标1", "指标2", "指标3", "指标4", "指标5", "指标6"],
          axisLabel: {
            show: true,
            textStyle: {
              color: "#fff",
            },
          },
        },

        yAxis: [
          {
            type: "value",
            splitLine: {
              show: false,
            },
            axisLabel: {
              show: true,
              textStyle: {
                color: "#fff",
              },
            },
          },
          {
            type: "value",
            min: 0,
            max: 100,
            interval: 20,
            splitLine: {
              show: false,
            },
            axisLabel: {
              formatter: "{value} %",
              show: true,
              textStyle: {
                color: "#fff",
              },
            },
          },
        ],
        series: [
          {
            name: "次数",
            type: "bar",
            barGap: "30%",
            barWidth: "40%",
            tooltip: {
              valueFormatter: function (value) {
                return value + "%";
              },
            },
            emphasis: {
              focus: "series",
            },
            itemStyle: {
              normal: {
                color: "#58c1f0",
              },
            },
            data: [800, 980, 620, 800, 620, 1000],
          },
          {
            name: "占比",
            type: "line",
            yAxisIndex: 1,
            symbol: "circle",
            symbolSize: 5,
            label: {
              show: true,
              textStyle: {
                color: "#fff",
              },
              formatter: function (value) {
                return value.value + "%";
              },
            },
            tooltip: {
              valueFormatter: function (value) {
                return value + "%";
              },
            },
            itemStyle: {
              normal: {
                color: "#FFC300",
                lineStyle: {
                  color: "#49CE7A",
                },
              },
            },
            data: [70, 80, 50, 70, 50, 95],
          },
        ],
      };

      myChart.setOption(option);

      window.addEventListener("resize", () => {
        myChart.resize();
      });
    },
    lastChartInit() {
      var myChart = echarts.init(document.getElementById("last"));
      // 漏斗图
      const option = {
        series: [
          {
            type: "funnel",
            left: "20%",
            top: 50,
            bottom: 60,
            width: "40%",
            min: 0,
            max: 8000,
            minSize: "0%",
            maxSize: "100%",
            sort: "ascending",
            gap: 10,
            label: {
              formatter: "{b|{b}}\n{c|{c}人} ",
              rich: {
                c: {
                  color: "#f4cf6d",
                  fontSize: 20,
                  lineHeight: 24,
                  height: 24,
                },
                b: {
                  color: "#fff",
                  fontSize: 14,
                  lineHeight: 20,
                  align: "left",
                },
              },
              textStyle: {
                color: "#fff",
                align: "right",
                fontSize: 14,
              },
            },
            labelLine: {
              length: 50,
              lineStyle: {
                width: 1,
                type: "solid",
              },
            },

            itemStyle: {
              borderWidth: "0",
            },
            emphasis: {
              label: {
                fontSize: 20,
              },
            },
            data: [
              { value: 2000, name: "博士生", num: 3002 },
              { value: 4000, name: "研究生", num: 14025 },
              { value: 6000, name: "本科生", num: 11009 },
              { value: 8000, name: "专科生", num: 20999 },
            ],
          },
        ],
      };
      myChart.setOption(option);

      window.addEventListener("resize", () => {
        myChart.resize();
      });
    },
    lineChart() {
      var myChart = echarts.init(document.getElementById("line"));
      const option = {
        grid: {
          top: "20%",
          left: "20%",
          right: "13%",
          bottom: "10%",
        },

        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "shadow",
          },
        },
        xAxis: {
          type: "category",
          axisTick: { show: false },
          data: [
            "2015",
            "2016",
            "2017",
            "2018",
            "2019",
            "2020",
            "2021",
            "2022",
          ],
          axisLabel: {
            show: true,
            textStyle: {
              color: "#fff",
            },
          },
        },

        yAxis: {
          name: "单位/人数",
          nameTextStyle: {
            color: "#fff",
            padding: 20,
          },
          type: "value",
          min: 0,
          max: 25000,
          interval: 5000,
          splitLine: {
            show: false,
          },
          axisLabel: {
            show: true,
            textStyle: {
              color: "#fff",
            },
          },
        },

        series: [
          {
            name: "占比",
            type: "line",
            symbolSize: 5,
            tooltip: {
              valueFormatter: function (value) {
                return value + "%";
              },
            },
            label: {
              show: true,
              textStyle: {
                color: "#4b94cb",
              },
            },
            itemStyle: {
              normal: {
                color: "#4b94cb",
                borderColor: "red",
                borderWidth: 5,
                lineStyle: {
                  color: "#4b94cb",
                },
              },
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                {
                  offset: 0,
                  color: "rgba(99, 195, 237,0.8)", //靠上方的透明颜色
                },
                {
                  offset: 1,
                  color: "rgba(0, 0, 84,0.3)", //靠下方的透明颜色
                },
              ]),
            },
            data: [12000, 17080, 18050, 19070, 19050, 22095, 18095, 12095],
          },
        ],
      };

      myChart.setOption(option);

      window.addEventListener("resize", () => {
        myChart.resize();
      });
    },
    getScale() {
      let { width, height } = this;
      let wh = window.innerHeight / height;
      let ww = window.innerWidth / width;
      return ww < wh ? ww : wh;
    },
    setScale() {
      this.scale = this.getScale();
      if (this.$refs.ScaleBox) {
        this.$refs.ScaleBox.style.setProperty("--scale", this.scale);
      }
    },
    debounce(fn, delay) {
      let delays = delay || 500;
      let timer;
      return function () {
        let th = this;
        let args = arguments;
        if (timer) {
          clearTimeout(timer);
        }
        timer = setTimeout(function () {
          timer = null;
          fn.apply(th, args);
        }, delays);
      };
    },
  },
};
</script>

<style scoped lang="scss">
/deep/.el-input__inner {
  background-color: rgba(0, 222, 255, 0.24);
  color: #fff;
  width: 144px;
  height: 38px;
  box-shadow: 0px 0px 16px 0px rgba(131, 219, 255, 0.2) inset;
  border-radius: 4px;
  border: none;
}
/deep/.el-form-item__label {
  color: #fff;
}
/deep/.el-input {
  width: 180px;
}

/deep/.el-button--primary {
  background: linear-gradient(0deg, #17e0fe, #0783cf);
}
/deep/.el-button {
  color: #fff;
  background-color: rgba(0, 222, 255, 0.24);
  box-shadow: 0px 0px 16px 0px rgba(131, 219, 255, 0.2) inset;
  border-radius: 4px;
  border: none;
}
/deep/.el-table tbody tr:hover > td {
  background: #0e183e !important;
}
/deep/.el-table {
  color: #00ffff;
  border: none;
  margin: 0;
}
/deep/table {
  width: 1232px !important;
}
/deep/.el-table tr {
  background-color: #071844;
}
/deep/.el-table td.el-table__cell {
  border: none;
}
/deep/.el-table__header {
  width: 1232px;
}
// 去掉表格单元格边框
/deep/.customer-table th {
  border: none;
}
/deep/.customer-table td,
.customer-table th.is-leaf {
  border: none;
}

// 头部边框
/deep/.customer-table thead tr th.is-leaf {
  border: none;
}
/deep/.customer-table thead tr th:nth-last-of-type(2) {
  border: none;
}
// 表格最外层边框-底部边框
/deep/.el-table--border::after,
.el-table--group::after {
  width: 0;
}
/deep/.customer-table::before {
  width: 0;
}
/deep/.customer-table .el-table__fixed-right::before,
.el-table__fixed::before {
  width: 0;
}

::v-deep .el-table__row.warning-row {
  background-color: #0e2550;
}
.form-search {
  margin: 20px 0 30px;
}
#ScaleBox {
  --scale: 1;
}
.ScaleBox {
  padding: 15px;
  position: absolute;
  transform: scale(var(--scale)) translate(-50%, -50%);
  display: flex;
  flex-direction: column;
  transform-origin: 0 0;
  left: 50%;
  top: 50%;
  transition: 0.3s;
  z-index: 999;
  background-color: #000337;
}
.page-content {
  padding: 20px 0;
}
.top {
  height: 80px;
  background: #000337;
  background: url("../assets/sanjiang/形状\ 14@2x.png") 62% 100% no-repeat;
  font-family: Source Han Sans CN;
  position: relative;
  .top-title {
    display: inline-block;
    width: 188px;
    height: 70px;
    margin-top: 25px;
    line-height: 100px;
    text-align: center;
    color: #2e9eff;
    background: url("../assets/sanjiang/1@2x.png") 50% 100% no-repeat;
  }
  .bg-choose{
    background: url("../assets/sanjiang/1@2x(1).png") 50% 100% no-repeat;
    color: #fff;
  }
  .top-text {
    position: absolute;
    top: -15px;
    left: 750px;
    background-image: -webkit-linear-gradient(bottom, #fff, #61f4f9);
    margin-left: 80px;
    width: 300px;
    height: 40px;
    margin-top: 40px;
    font-size: 32px;
    display: inline-block;
    font-weight: bold;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    overflow: hidden;
  }
  .left-50 {
    margin-left: 450px;
  }
  .top-right {
    margin-left: 20px;
  }
}
.chart {
  background: url("../assets/sanjiang/组\ 18@2x\(2\).png") no-repeat;
  background-size: cover;
  background-size: 100% 95%;
  width: 100%;
  height: 480px;
  .title {
    font-weight: 600;
    text-align: center;
    font-size: 20px;
    line-height: 70px;
    background-image: linear-gradient(
      92deg,
      #000054 35%,
      #b1f5fa 48.8525390625%,
      #75c8fa 100%
    );
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }
}
.mt-40 {
  margin-top: 35px;
}
.ml-10 {
  margin-left: 10px !important;
}
.chart-center {
  background: url("../assets/sanjiang/组\ 18@2x\(4\).png") no-repeat;
  background-size: 100% 95%;
  width: 100%;
  height: 480px;
  .title {
    font-weight: 600;
    text-align: center;
    font-size: 20px;
    line-height: 70px;
    background-image: linear-gradient(
      92deg,
      #000054 35%,
      #b1f5fa 48.8525390625%,
      #75c8fa 100%
    );
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }
}
#bar {
  height: 350px;
}
#line {
  height: 350px;
}

#last {
  height: 350px;
}
#categoryDiv {
  height: 350px;
}
.five{
  position: relative;
  img{
    position: absolute;
    top: 250px;
    left: 40px;
    width: 400px;
  }
}
.bottom-title {
  color: #fff;
  text-align: center;
  margin-top: 15px;
  span {
    margin-right: 15px;
    background: linear-gradient(
      0deg,
      rgba(51, 214, 255, 0.3),
      rgba(51, 229, 255, 0.8)
    );
    border-radius: 10px;
    padding: 5px 10px;
    font-size: 14px;
    cursor: pointer;
  }
  span:last-child {
    background: linear-gradient(
      0deg,
      rgba(255, 226, 101, 0.6),
      rgba(255, 156, 0, 0.6)
    );
  }
}
.content {
  padding: 20px;
  background: url("../assets/sanjiang/组\ 18@2x\(3\).png") no-repeat;
  background-size: 100% 100%;
  box-sizing: border-box;
  width: 250px;
  height: 170px;
  display: inline-block;
  margin: 10px 0 0 20px;
  .content-title {
    font-size: 18px;
    color: #fff;
    padding-bottom: 10px;
    border-bottom: 1px dashed #fff;
  }
  .content-content {
    font-size: 28px;
    color: #46e2ff;
    margin-top: 10px;
    span {
      font-size: 14px;
    }
  }
  .content-bottom {
    width: 100px;
    height: 20px;
    line-height: 20px;
    margin-top: 15px;
    text-align: center;
    font-size: 12px;
    color: #3dff00;
    box-shadow: 0px 12px 7px 0px rgba(16, 85, 216, 0.35) inset;
    border: 1px solid #209bd3;
    border-radius: 100px;
    img {
      width: 18px;
    }
  }
}
.top-box {
  padding: 30px 50px;
  .line {
    display: inline-block;
    width: 1px;
    height: 100px;
    margin: 0 45px;
    background: linear-gradient(
      0deg,
      rgba(255, 255, 255, 0) 0%,
      rgba(70, 226, 255, 0.97) 50%,
      rgba(255, 255, 255, 0) 100%
    );
  }
  .top-content {
    width: 300px;
    font-size: 16px;
    margin-bottom: 20px;
    display: inline-block;
    line-height: 32px;
    color: #fff;
    height: 70px;

    .top-img {
      display: block;
      width: 60px;
    }
    .apply {
      font-size: 13px !important;
    }
    .num {
      font-size: 30px;
      font-weight: 600;
      background: linear-gradient(0deg, #2bb3ff 0%, #38e7ee 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    .content-bottom {
      width: 100px;
      height: 20px;
      line-height: 20px;
      margin-top: 15px;
      text-align: center;
      font-size: 12px;
      color: #3dff00;
      border: 1px solid #209bd3;
      border-radius: 100px;
      box-shadow: 0px 12px 7px 0px rgba(16, 85, 216, 0.35) inset;
      img {
        width: 18px;
      }
    }
  }
}

.right-box {
  width: 150px;
  font-size: 14px;
  color: #fff;
  float: right;
  margin-top: 25px;
  line-height: 18px;
  cursor: pointer;
  .right-content {
    // padding: 35px 20px;
    img {
      display: block;
      width: 20px;
      margin-top: 7px;
    }
    .num {
      text-align: left;
    }
    .apply {
      text-align: left;
    }
  }
}
</style>
