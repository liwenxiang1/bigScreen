<template>
  <div>
     <IndexPage class="index"></IndexPage>
    <!-- <SecondPage class="index"></SecondPage> -->
    <!-- <ThirdPage class="index"></ThirdPage> -->
    <!-- <FourthPage class="index"></FourthPage> -->
  </div>
   
</template>

<script>
import IndexPage from "./components/IndexPage.vue";
// import SecondPage from "./components/SecondPage.vue";
// import ThirdPage from "./components/ThirdPage.vue";
// import FourthPage from "./components/FourthPage.vue";

export default {
  name: "App",
  components: {
    IndexPage,
    // SecondPage,
    // ThirdPage,
    // FourthPage
  },
};
</script>

<style>
* {
  margin: 0;
  padding: 0;
}
html,
body {
  width: 100%;
  height: 100%;
  background-color: #010334;
}
</style>
